// GENERATED FILE - DO NOT MODIFY MANUALLY
namespace Telegram.Bot.Types
{
    /// <summary>This object represents a service message about a video chat started in the chat. Currently holds no information.</summary>
    public partial class VideoChatStarted{}
}
