//-----------------------------------------------------------------------
// <copyright file="AttributeTargetFlags.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#define ODIN_INSPECTOR
#define ODIN_INSPECTOR_3
#define ODIN_INSPECTOR_3_1
#define ODIN_INSPECTOR_3_2
#define ODIN_INSPECTOR_3_3
namespace Sirenix.OdinInspector
{
#pragma warning disable

    using System;

    /// <summary>
    /// Not yet documented.
    /// </summary>
    public static class AttributeTargetFlags
    {
        /// <summary>
        /// Not yet documented.
        /// </summary>
        public const AttributeTargets Default = AttributeTargets.All;
    }
}