//-----------------------------------------------------------------------
// <copyright file="HeaderAttributeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
#define ODIN_INSPECTOR
#define ODIN_INSPECTOR_3
#define ODIN_INSPECTOR_3_1
#define ODIN_INSPECTOR_3_2
#define ODIN_INSPECTOR_3_3
namespace Sirenix.OdinInspector.Editor.Drawers
{
#pragma warning disable

    using Editor;
    using ValueResolvers;
    using Sirenix.Utilities.Editor;
    using UnityEditor;
    using UnityEngine;

    /// <summary>
    /// Draws properties marked with <see cref="HeaderAttribute"/>.
    /// </summary>
    /// <seealso cref="HeaderAttribute"/>
    /// <seealso cref="TitleAttribute"/>
    /// <seealso cref="HideLabelAttribute"/>
    /// <seealso cref="LabelTextAttribute"/>
    /// <seealso cref="SpaceAttribute"/>
    [DrawerPriority(1, 0, 0)]
    public sealed class HeaderAttributeDrawer : OdinAttributeDrawer<HeaderAttribute>
    {
        private ValueResolver<string> textResolver;

        protected override void Initialize()
        {
            // Don't draw for collection elements
            if (Property.Parent != null && Property.Parent.ChildResolver is ICollectionResolver)
            {
                SkipWhenDrawing = true;
                return;
            }

            textResolver = ValueResolver.GetForString(Property, Attribute.header);
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            if (Property != Property.Tree.GetRootProperty(0))
            {
                EditorGUILayout.Space();
            }

            if (textResolver.HasError)
            {
                SirenixEditorGUI.ErrorMessageBox(textResolver.ErrorMessage);
            }
            else
            {
                EditorGUILayout.LabelField(textResolver.GetValue(), EditorStyles.boldLabel);
            }

            CallNextDrawer(label);
        }
    }
}
#endif