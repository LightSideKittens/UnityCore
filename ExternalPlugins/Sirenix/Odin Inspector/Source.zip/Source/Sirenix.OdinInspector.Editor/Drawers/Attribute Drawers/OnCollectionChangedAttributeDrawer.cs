//-----------------------------------------------------------------------
// <copyright file="OnCollectionChangedAttributeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
#define ODIN_INSPECTOR
#define ODIN_INSPECTOR_3
#define ODIN_INSPECTOR_3_1
#define ODIN_INSPECTOR_3_2
#define ODIN_INSPECTOR_3_3
namespace Sirenix.OdinInspector.Editor.Drawers
{
#pragma warning disable

    using UnityEngine;
    using System;
    using ActionResolvers;

    /// <summary>
    /// Draws properties marked with <see cref="OnCollectionChangedAttribute"/>.
    /// </summary>
    /// <seealso cref="OnCollectionChangedAttribute"/>
    /// <seealso cref="OnValueChangedAttribute"/>
    /// <seealso cref="OnInspectorGUIAttribute"/>
    /// <seealso cref="ValidateInputAttribute"/>
    /// <seealso cref="InfoBoxAttribute"/>
    [DrawerPriority(DrawerPriorityLevel.SuperPriority)]
    public sealed class OnCollectionChangedAttributeDrawer : OdinAttributeDrawer<OnCollectionChangedAttribute>, IDisposable
    {
        private static readonly NamedValue[] ActionArgs = new NamedValue[]
        {
            new NamedValue("info", typeof(CollectionChangeInfo))
        };

        private ActionResolver onBefore;
        private ActionResolver onAfter;
        private ICollectionResolver resolver;

        protected override bool CanDrawAttributeProperty(InspectorProperty property)
        {
            return property.ChildResolver is ICollectionResolver;
        }

        protected override void Initialize()
        {
            resolver = (ICollectionResolver)Property.ChildResolver;

            if (Attribute.Before != null)
            {
                onBefore = ActionResolver.Get(Property, Attribute.Before, ActionArgs);
                
                if (!onBefore.HasError)
                {
                    resolver.OnBeforeChange += OnBeforeChange;
                }
            }

            if (Attribute.After != null)
            {
                onAfter = ActionResolver.Get(Property, Attribute.After, ActionArgs);
                
                if (!onAfter.HasError)
                {
                    resolver.OnAfterChange += OnAfterChange;
                }
            }

            if ((onAfter == null || !onAfter.HasError)
                && (onBefore == null || !onBefore.HasError))
            {
                SkipWhenDrawing = true;
            }
        }

        private void OnBeforeChange(CollectionChangeInfo info)
        {
            onBefore.Context.NamedValues.Set("info", info);
            onBefore.DoAction(info.SelectionIndex);
        }

        private void OnAfterChange(CollectionChangeInfo info)
        {
            onAfter.Context.NamedValues.Set("info", info);
            onAfter.DoAction(info.SelectionIndex);
        }

        protected override void DrawPropertyLayout(GUIContent label)
        {
            ActionResolver.DrawErrors(onBefore, onAfter);
            CallNextDrawer(label);
        }

        public void Dispose()
        {
            if (onBefore != null)
            {
                resolver.OnBeforeChange -= OnBeforeChange;
            }

            if (onAfter != null)
            {
                resolver.OnAfterChange -= OnAfterChange;
            }
        }
    }
}
#endif