//-----------------------------------------------------------------------
// <copyright file="GUIColorAttributeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
#define ODIN_INSPECTOR
#define ODIN_INSPECTOR_3
#define ODIN_INSPECTOR_3_1
#define ODIN_INSPECTOR_3_2
#define ODIN_INSPECTOR_3_3
namespace Sirenix.OdinInspector.Editor.Drawers
{
#pragma warning disable

    using UnityEngine;
    using Sirenix.Utilities.Editor;
    using ValueResolvers;

    /// <summary>
    /// Draws properties marked with <see cref="GUIColorAttribute"/>.
    /// This drawer sets the current GUI color, before calling the next drawer in the chain.
    /// </summary>
    /// <seealso cref="GUIColorAttribute"/>
    /// <seealso cref="LabelTextAttribute"/>
    /// <seealso cref="TitleAttribute"/>
    /// <seealso cref="HeaderAttribute"/>
    /// <seealso cref="ColorPaletteAttribute"/>
    [DrawerPriority(0.5, 0, 0)]
    public sealed class GUIColorAttributeDrawer : OdinAttributeDrawer<GUIColorAttribute>
    {
        internal static Color CurrentOuterColor = Color.white;

        private ValueResolver<Color> colorResolver;

        protected override void Initialize()
        {
            colorResolver = ValueResolver.Get(Property, Attribute.GetColor, Attribute.Color);
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            if (colorResolver.HasError)
            {
                SirenixEditorGUI.ErrorMessageBox(colorResolver.ErrorMessage);
                CallNextDrawer(label);
            }
            else
            {
                GUIHelper.PushColor(colorResolver.GetValue());
                CallNextDrawer(label);
                GUIHelper.PopColor();
            }
        }
    }
}
#endif