//-----------------------------------------------------------------------
// <copyright file="ToggleAttributeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
#define ODIN_INSPECTOR
#define ODIN_INSPECTOR_3
#define ODIN_INSPECTOR_3_1
#define ODIN_INSPECTOR_3_2
#define ODIN_INSPECTOR_3_3
namespace Sirenix.OdinInspector.Editor.Drawers
{
#pragma warning disable

    using Utilities.Editor;
    using UnityEngine;

    /// <summary>
    /// Draws properties marked with <see cref="ToggleAttribute"/>.
    /// </summary>
    /// <seealso cref="ToggleAttribute"/>
    public class ToggleAttributeDrawer : OdinAttributeDrawer<ToggleAttribute>
    {
        private InspectorProperty toggleProperty;
        private PropertyContext<string> openToggleGlobalContext;

        protected override void Initialize()
        {
            toggleProperty = Property.Children.Get(Attribute.ToggleMemberName);

            if (Attribute.CollapseOthersOnExpand)
            {
                var parent = Property.ParentValueProperty;

                while (parent != null && !parent.Info.HasBackingMembers)
                {
                    parent = parent.ParentValueProperty;
                }

                if (parent == null) parent = Property.Tree.RootProperty;

                // This works together with other "parallel" ToggleGroupAttributeDrawers and ToggleAttributeDrawers.
                openToggleGlobalContext = parent.Context.GetGlobal<string>("OpenFoldoutToggleGroup", (string)null);
            }
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            if (toggleProperty == null)
            {
                SirenixEditorGUI.ErrorMessageBox(Attribute.ToggleMemberName + " is not a member of " + Property.NiceName + ".");
            }
            else if (toggleProperty.ValueEntry.TypeOfValue != typeof(bool))
            {
                SirenixEditorGUI.ErrorMessageBox(Attribute.ToggleMemberName + " on " + Property.NiceName + "  must be a boolean.");
            }
            else
            {
                bool isEnabled = (bool)toggleProperty.ValueEntry.WeakSmartValue;

                if (Attribute.CollapseOthersOnExpand && openToggleGlobalContext != null && openToggleGlobalContext.Value != null && openToggleGlobalContext.Value != Property.Path)
                {
                    Property.State.Expanded = false;
                }

                bool prev = Property.State.Expanded;
                bool visibleBuffer = Property.State.Expanded;
                if (SirenixEditorGUI.BeginToggleGroup(UniqueDrawerKey.Create(Property, this), ref isEnabled, ref visibleBuffer, label != null ? label.text : Property.NiceName))
                {
                    for (int i = 0; i < Property.Children.Count; i++)
                    {
                        var child = Property.Children[i];
                        if (child != toggleProperty)
                        {
                            child.Draw(child.Label);
                        }
                    }
                }
                SirenixEditorGUI.EndToggleGroup();

                Property.State.Expanded = visibleBuffer;
                if (openToggleGlobalContext != null && prev != Property.State.Expanded && Property.State.Expanded)
                {
                    openToggleGlobalContext.Value = Property.Path;
                }

                toggleProperty.ValueEntry.WeakSmartValue = isEnabled;
            }
        }
    }
}
#endif