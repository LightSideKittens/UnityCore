//-----------------------------------------------------------------------
// <copyright file="PropertySpaceAttributeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
#define ODIN_INSPECTOR
#define ODIN_INSPECTOR_3
#define ODIN_INSPECTOR_3_1
#define ODIN_INSPECTOR_3_2
#define ODIN_INSPECTOR_3_3
namespace Sirenix.OdinInspector.Editor.Drawers
{
#pragma warning disable

    using UnityEngine;

    /// <summary>
    /// Draws a space for properties marked with the PropertySpace attribute.
    /// </summary>
    [DrawerPriority(2, 0, 0)]
    public sealed class PropertySpaceAttributeDrawer : OdinAttributeDrawer<PropertySpaceAttribute>
    {
        private bool drawSpace;

        /// <summary>
        /// Initializes this instance.
        /// </summary>
        protected override void Initialize()
        {
            if (Property.Parent == null)
            {
                drawSpace = true;
            }
            else if (Property.Parent.ChildResolver is ICollectionResolver)
            {
                drawSpace = false;
            }
            else
            {
                drawSpace = true;
            }
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            if (drawSpace && Attribute.SpaceBefore != 0f)
            {
                GUILayout.Space(Attribute.SpaceBefore);
            }

            CallNextDrawer(label);

            if (Attribute.SpaceAfter != 0f)
            {
                GUILayout.Space(Attribute.SpaceAfter);
            }
        }
    }
}
#endif