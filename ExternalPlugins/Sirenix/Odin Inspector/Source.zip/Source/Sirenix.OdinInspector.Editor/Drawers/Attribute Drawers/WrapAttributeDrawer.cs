//-----------------------------------------------------------------------
// <copyright file="WrapAttributeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
#define ODIN_INSPECTOR
#define ODIN_INSPECTOR_3
#define ODIN_INSPECTOR_3_1
#define ODIN_INSPECTOR_3_2
#define ODIN_INSPECTOR_3_3
namespace Sirenix.OdinInspector.Editor
{
#pragma warning disable

    using Utilities;
    using OdinInspector;
    using UnityEngine;

    /// <summary>
    /// Draws short properties marked with <see cref="WrapAttribute"/>.
    /// </summary>
    /// <seealso cref="WrapAttribute"/>
    [DrawerPriority(0.3, 0, 0)]
    public class WrapAttributeInt16Drawer : OdinAttributeDrawer<WrapAttribute, short>
    {
        /// <summary>
        /// Not yet documented.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            var entry = ValueEntry;
            var attribute = Attribute;

            CallNextDrawer(label);
            ValueEntry.SmartValue = (short)MathUtilities.Wrap(ValueEntry.SmartValue, Attribute.Min, Attribute.Max);
        }
    }

    /// <summary>
    /// Draws int properties marked with <see cref="WrapAttribute"/>.
    /// </summary>
    /// <seealso cref="WrapAttribute"/>
    [DrawerPriority(0.3, 0, 0)]
    public class WrapAttributeInt32Drawer : OdinAttributeDrawer<WrapAttribute, int>
    {
        /// <summary>
        /// Not yet documented.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            var entry = ValueEntry;
            var attribute = Attribute;

            CallNextDrawer(label);
            ValueEntry.SmartValue = (int)MathUtilities.Wrap(ValueEntry.SmartValue, Attribute.Min, Attribute.Max);
        }
    }

    /// <summary>
    /// Draws long properties marked with <see cref="WrapAttribute"/>.
    /// </summary>
    /// <seealso cref="WrapAttribute"/>
    [DrawerPriority(0.3, 0, 0)]
    public class WrapAttributeInt64Drawer : OdinAttributeDrawer<WrapAttribute, long>
    {
        /// <summary>
        /// Not yet documented.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            var entry = ValueEntry;
            var attribute = Attribute;

            CallNextDrawer(label);
            ValueEntry.SmartValue = (long)MathUtilities.Wrap(ValueEntry.SmartValue, Attribute.Min, Attribute.Max);
        }
    }

    /// <summary>
    /// Draws float properties marked with <see cref="WrapAttribute"/>.
    /// </summary>
    /// <seealso cref="WrapAttribute"/>
    [DrawerPriority(0.3, 0, 0)]
    public class WrapAttributeFloatDrawer : OdinAttributeDrawer<WrapAttribute, float>
    {
        /// <summary>
        /// Not yet documented.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            CallNextDrawer(label);
            ValueEntry.SmartValue = (float)MathUtilities.Wrap(ValueEntry.SmartValue, Attribute.Min, Attribute.Max);
        }
    }

    /// <summary>
    /// Draws double properties marked with <see cref="WrapAttribute"/>.
    /// </summary>
    /// <seealso cref="WrapAttribute"/>
    [DrawerPriority(0.3, 0, 0)]
    public class WrapAttributeDoubleDrawer : OdinAttributeDrawer<WrapAttribute, double>
    {
        /// <summary>
        /// Not yet documented.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            CallNextDrawer(label);
            ValueEntry.SmartValue = (double)MathUtilities.Wrap(ValueEntry.SmartValue, Attribute.Min, Attribute.Max);
        }
    }

    /// <summary>
    /// Draws decimal properties marked with <see cref="WrapAttribute"/>.
    /// </summary>
    /// <seealso cref="WrapAttribute"/>
    [DrawerPriority(0.3, 0, 0)]
    public class WrapAttributeDecimalDrawer : OdinAttributeDrawer<WrapAttribute, decimal>
    {
        /// <summary>
        /// Not yet documented.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            CallNextDrawer(label);
            ValueEntry.SmartValue = (decimal)MathUtilities.Wrap((double)ValueEntry.SmartValue, Attribute.Min, Attribute.Max);
        }
    }

    /// <summary>
    /// Draws Vector2 properties marked with <see cref="WrapAttribute"/>.
    /// </summary>
    /// <seealso cref="WrapAttribute"/>
    [DrawerPriority(0.3, 0, 0)]
    public class WrapAttributeVector2Drawer : OdinAttributeDrawer<WrapAttribute, Vector2>
    {
        /// <summary>
        /// Not yet documented.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            CallNextDrawer(label);
            ValueEntry.SmartValue = new Vector2(
                MathUtilities.Wrap(ValueEntry.SmartValue.x, (float)Attribute.Min, (float)Attribute.Max),
                MathUtilities.Wrap(ValueEntry.SmartValue.y, (float)Attribute.Min, (float)Attribute.Max));
        }
    }

    /// <summary>
    /// Draws Vector3 properties marked with <see cref="WrapAttribute"/>.
    /// </summary>
    /// <seealso cref="WrapAttribute"/>
    [DrawerPriority(0.3, 0, 0)]
    public class WrapAttributeVector3Drawer : OdinAttributeDrawer<WrapAttribute, Vector3>
    {
        /// <summary>
        /// Not yet documented.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            CallNextDrawer(label);
            ValueEntry.SmartValue = new Vector3(
                MathUtilities.Wrap(ValueEntry.SmartValue.x, (float)Attribute.Min, (float)Attribute.Max),
                MathUtilities.Wrap(ValueEntry.SmartValue.y, (float)Attribute.Min, (float)Attribute.Max),
                MathUtilities.Wrap(ValueEntry.SmartValue.z, (float)Attribute.Min, (float)Attribute.Max));
        }
    }

    /// <summary>
    /// Draws Vector4 properties marked with <see cref="WrapAttribute"/>.
    /// </summary>
    /// <seealso cref="WrapAttribute"/>
    [DrawerPriority(0.3, 0, 0)]
    public class WrapAttributeVector4Drawer : OdinAttributeDrawer<WrapAttribute, Vector4>
    {
        /// <summary>
        /// Not yet documented.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            CallNextDrawer(label);
            ValueEntry.SmartValue = new Vector4(
                MathUtilities.Wrap(ValueEntry.SmartValue.x, (float)Attribute.Min, (float)Attribute.Max),
                MathUtilities.Wrap(ValueEntry.SmartValue.y, (float)Attribute.Min, (float)Attribute.Max),
                MathUtilities.Wrap(ValueEntry.SmartValue.z, (float)Attribute.Min, (float)Attribute.Max),
                MathUtilities.Wrap(ValueEntry.SmartValue.w, (float)Attribute.Min, (float)Attribute.Max));
        }
    }
}
#endif