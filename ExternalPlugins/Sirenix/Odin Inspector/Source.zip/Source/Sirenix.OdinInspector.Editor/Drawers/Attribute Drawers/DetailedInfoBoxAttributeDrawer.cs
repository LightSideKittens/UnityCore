//-----------------------------------------------------------------------
// <copyright file="DetailedInfoBoxAttributeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
#define ODIN_INSPECTOR
#define ODIN_INSPECTOR_3
#define ODIN_INSPECTOR_3_1
#define ODIN_INSPECTOR_3_2
#define ODIN_INSPECTOR_3_3
namespace Sirenix.OdinInspector.Editor.Drawers
{
#pragma warning disable

    using Utilities.Editor;
    using UnityEngine;
    using ValueResolvers;

    /// <summary>
    ///	Draws properties marked with <see cref="DetailedInfoBoxAttribute"/>.
    /// </summary>
    /// <seealso cref="DetailedInfoBoxAttribute"/>
    /// <seealso cref="InfoBoxAttribute"/>
    /// <seealso cref="RequiredAttribute"/>
    /// <seealso cref="OnInspectorGUIAttribute"/>
    [DrawerPriority(0, 100, 0)]
    public sealed class DetailedInfoBoxAttributeDrawer : OdinAttributeDrawer<DetailedInfoBoxAttribute>
    {
        private bool drawMessageBox;
        //private bool hideDetailedMessage;
        private UnityEditor.MessageType messageType;
        private bool valid;

        private ValueResolver<bool> visibleIfGetter;
        private ValueResolver<string> messageGetter;
        private ValueResolver<string> detailsGetter;

        /// <summary>
        /// Initializes this instance.
        /// </summary>
        protected override void Initialize()
        {
            visibleIfGetter = ValueResolver.Get<bool>(Property, Attribute.VisibleIf, true);
            messageGetter = ValueResolver.GetForString(Property, Attribute.Message);
            detailsGetter = ValueResolver.GetForString(Property, Attribute.Details);

            valid = !(visibleIfGetter.HasError || messageGetter.HasError || detailsGetter.HasError);

            Property.State.Create<bool>("ShowDetailedMessage", false, false);
            //this.hideDetailedMessage = true;

            switch (Attribute.InfoMessageType)
            {
                case InfoMessageType.None:
                    messageType = UnityEditor.MessageType.None;
                    break;

                case InfoMessageType.Info:
                    messageType = UnityEditor.MessageType.Info;
                    break;

                case InfoMessageType.Warning:
                    messageType = UnityEditor.MessageType.Warning;
                    break;

                case InfoMessageType.Error:
                    messageType = UnityEditor.MessageType.Error;
                    break;

                default:
                    Debug.LogError("Unknown InfoBoxType: " + Attribute.InfoMessageType.ToString());
                    break;
            }
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            ValueResolver.DrawErrors(visibleIfGetter, messageGetter, detailsGetter);

            if (valid)
            {
                if (Event.current.type == EventType.Layout)
                {
                    drawMessageBox = visibleIfGetter.GetValue();
                }

                if (drawMessageBox)
                {
                    Property.State.Set<bool>("ShowDetailedMessage", !SirenixEditorGUI.DetailedMessageBox(
                        message:                messageGetter.GetValue(),
                        detailedMessage:        detailsGetter.GetValue(),
                        messageType:            messageType,
                        hideDetailedMessage: !Property.State.Get<bool>("ShowDetailedMessage")));
                }
            }

            CallNextDrawer(label);
        }
    }
}
#endif