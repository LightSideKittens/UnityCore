//-----------------------------------------------------------------------
// <copyright file="OnInspectorGUIAttributeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
#define ODIN_INSPECTOR
#define ODIN_INSPECTOR_3
#define ODIN_INSPECTOR_3_1
#define ODIN_INSPECTOR_3_2
#define ODIN_INSPECTOR_3_3
namespace Sirenix.OdinInspector.Editor.Drawers
{
#pragma warning disable

    using UnityEngine;
    using ActionResolvers;

    /// <summary>
    /// Draws properties marked with <see cref="OnInspectorGUIAttribute"/>.
    /// Calls the method, the attribute is either attached to, or the method that has been specified in the attribute, to allow for custom GUI drawing.
    /// </summary>
    /// <seealso cref="OnInspectorGUIAttribute"/>
    /// <seealso cref="OnValueChangedAttribute"/>
    /// <seealso cref="ValidateInputAttribute"/>
    /// <seealso cref="DrawWithUnityAttribute"/>
    ///	<seealso cref="InlineEditorAttribute"/>
    [DrawerPriority(DrawerPriorityLevel.WrapperPriority)]
    public sealed class OnInspectorGUIAttributeDrawer : OdinAttributeDrawer<OnInspectorGUIAttribute>
    {
        private ActionResolver propertyMethod;
        private ActionResolver prependGUI;
        private ActionResolver appendGUI;

        protected override void Initialize()
        {
            if (Property.Info.PropertyType == PropertyType.Method)
            {
                propertyMethod = ActionResolver.Get(Property, null);
            }
            else
            {
                if (Attribute.Prepend != null)
                {
                    prependGUI = ActionResolver.Get(Property, Attribute.Prepend);
                }

                if (Attribute.Append != null)
                {
                    appendGUI = ActionResolver.Get(Property, Attribute.Append);
                }
            }
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            if (Property.Info.PropertyType == PropertyType.Method)
            {
                if (propertyMethod.HasError)
                    propertyMethod.DrawError();
                else
                    propertyMethod.DoAction();
            }
            else
            {
                // Draw errors, if any
                ActionResolver.DrawErrors(prependGUI, appendGUI);

                // Draw the actual GUI
                if (prependGUI != null && !prependGUI.HasError) prependGUI.DoAction();
                CallNextDrawer(label);
                if (appendGUI != null && !appendGUI.HasError) appendGUI.DoAction();
            }
        }
    }
}
#endif