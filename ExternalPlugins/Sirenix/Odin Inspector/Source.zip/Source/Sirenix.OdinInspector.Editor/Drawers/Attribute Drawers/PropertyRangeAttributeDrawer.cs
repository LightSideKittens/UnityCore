//-----------------------------------------------------------------------
// <copyright file="PropertyRangeAttributeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
#define ODIN_INSPECTOR
#define ODIN_INSPECTOR_3
#define ODIN_INSPECTOR_3_1
#define ODIN_INSPECTOR_3_2
#define ODIN_INSPECTOR_3_3
namespace Sirenix.OdinInspector.Editor.Drawers
{
#pragma warning disable

    using System;
    using ValueResolvers;
    using Sirenix.Utilities.Editor;
    using UnityEditor;
    using UnityEngine;

    /// <summary>
    /// Draws byte properties marked with <see cref="PropertyRangeAttribute"/>.
    /// </summary>
    /// <seealso cref="PropertyRangeAttribute"/>
    /// <seealso cref="MinValueAttribute"/>
    /// <seealso cref="MaxValueAttribute"/>
    /// <seealso cref="MinMaxSliderAttribute"/>
    /// <seealso cref="DelayedAttribute"/>
    /// <seealso cref="WrapAttribute"/>
    public sealed class PropertyRangeAttributeByteDrawer : OdinAttributeDrawer<PropertyRangeAttribute, byte>
    {
        private ValueResolver<byte> getterMinValue;
        private ValueResolver<byte> getterMaxValue;

        /// <summary>
        /// Initialized the drawer.
        /// </summary>
        protected override void Initialize()
        {
            if (Attribute.MinGetter != null)
            {
                getterMinValue = ValueResolver.Get<byte>(Property, Attribute.MinGetter);
            }
            if (Attribute.MaxGetter != null)
            {
                getterMaxValue = ValueResolver.Get<byte>(Property, Attribute.MaxGetter);
            }
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            byte min = getterMinValue != null ? getterMinValue.GetValue() : (byte)Attribute.Min;
            byte max = getterMaxValue != null ? getterMaxValue.GetValue() : (byte)Attribute.Max;

            if (getterMinValue != null && getterMinValue.ErrorMessage != null)
            {
                SirenixEditorGUI.ErrorMessageBox(getterMinValue.ErrorMessage);
            }
            if (getterMaxValue != null && getterMaxValue.ErrorMessage != null)
            {
                SirenixEditorGUI.ErrorMessageBox(getterMaxValue.ErrorMessage);
            }

            EditorGUI.BeginChangeCheck();
            int value = SirenixEditorFields.RangeIntField(label, ValueEntry.SmartValue, Mathf.Min(min, max), Mathf.Max(min, max));
            if (EditorGUI.EndChangeCheck())
            {
                if (value < byte.MinValue)
                {
                    value = byte.MinValue;
                }
                else if (value > byte.MaxValue)
                {
                    value = byte.MaxValue;
                }

                ValueEntry.SmartValue = (byte)value;
            }
        }
    }

    /// <summary>
    /// Draws double properties marked with <see cref="PropertyRangeAttribute"/>.
    /// </summary>
    /// <seealso cref="PropertyRangeAttribute"/>
    /// <seealso cref="MinValueAttribute"/>
    /// <seealso cref="MaxValueAttribute"/>
    /// <seealso cref="MinMaxSliderAttribute"/>
    /// <seealso cref="DelayedAttribute"/>
    /// <seealso cref="WrapAttribute"/>
    public sealed class PropertyRangeAttributeDoubleDrawer : OdinAttributeDrawer<PropertyRangeAttribute, double>
    {
        private ValueResolver<double> getterMinValue;
        private ValueResolver<double> getterMaxValue;

        /// <summary>
        /// Initialized the drawer.
        /// </summary>
        protected override void Initialize()
        {
            if (Attribute.MinGetter != null)
            {
                getterMinValue = ValueResolver.Get<double>(Property, Attribute.MinGetter);
            }
            if (Attribute.MaxGetter != null)
            {
                getterMaxValue = ValueResolver.Get<double>(Property, Attribute.MaxGetter);
            }
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            // TODO: There's currently no SirenixEditorFields.DoubleRangeField, so we're making do with the float field. This should be fixed.
            double value = ValueEntry.SmartValue;
            if (value < float.MinValue)
            {
                value = float.MinValue;
            }
            else if (value > float.MaxValue)
            {
                value = float.MaxValue;
            }

            double min = getterMinValue != null ? getterMinValue.GetValue() : Attribute.Min;
            double max = getterMaxValue != null ? getterMaxValue.GetValue() : Attribute.Max;

            if (getterMinValue != null && getterMinValue.ErrorMessage != null)
            {
                SirenixEditorGUI.ErrorMessageBox(getterMinValue.ErrorMessage);
            }
            if (getterMaxValue != null && getterMaxValue.ErrorMessage != null)
            {
                SirenixEditorGUI.ErrorMessageBox(getterMaxValue.ErrorMessage);
            }

            EditorGUI.BeginChangeCheck();
            value = SirenixEditorFields.RangeFloatField(label, (float)value, (float)Math.Min(min, max), (float)Math.Max(min, max));
            if (EditorGUI.EndChangeCheck())
            {
                ValueEntry.SmartValue = value;
            }
        }
    }

    /// <summary>
    /// Draws float properties marked with <see cref="PropertyRangeAttribute"/>.
    /// </summary>
    /// <seealso cref="PropertyRangeAttribute"/>
    /// <seealso cref="MinValueAttribute"/>
    /// <seealso cref="MaxValueAttribute"/>
    /// <seealso cref="MinMaxSliderAttribute"/>
    /// <seealso cref="DelayedAttribute"/>
    /// <seealso cref="WrapAttribute"/>
    public sealed class PropertyRangeAttributeFloatDrawer : OdinAttributeDrawer<PropertyRangeAttribute, float>
    {
        private ValueResolver<float> getterMinValue;
        private ValueResolver<float> getterMaxValue;

        /// <summary>
        /// Initialized the drawer.
        /// </summary>
        protected override void Initialize()
        {
            if (Attribute.MinGetter != null)
            {
                getterMinValue = ValueResolver.Get<float>(Property, Attribute.MinGetter);
            }
            if (Attribute.MaxGetter != null)
            {
                getterMaxValue = ValueResolver.Get<float>(Property, Attribute.MaxGetter);
            }
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            float min = getterMinValue != null ? getterMinValue.GetValue() : (float)Attribute.Min;
            float max = getterMaxValue != null ? getterMaxValue.GetValue() : (float)Attribute.Max;

            if (getterMinValue != null && getterMinValue.ErrorMessage != null)
            {
                SirenixEditorGUI.ErrorMessageBox(getterMinValue.ErrorMessage);
            }
            if (getterMaxValue != null && getterMaxValue.ErrorMessage != null)
            {
                SirenixEditorGUI.ErrorMessageBox(getterMaxValue.ErrorMessage);
            }

            EditorGUI.BeginChangeCheck();
            float value = SirenixEditorFields.RangeFloatField(label, ValueEntry.SmartValue, Mathf.Min(min, max), Mathf.Max(min, max));
            if (EditorGUI.EndChangeCheck())
            {
                ValueEntry.SmartValue = value;
            }
        }
    }

    /// <summary>
    /// Draws decimal properties marked with <see cref="PropertyRangeAttribute"/>.
    /// </summary>
    public sealed class PropertyRangeAttributeDecimalDrawer : OdinAttributeDrawer<PropertyRangeAttribute, decimal>
    {
        private ValueResolver<decimal> getterMinValue;
        private ValueResolver<decimal> getterMaxValue;

        /// <summary>
        /// Initialized the drawer.
        /// </summary>
        protected override void Initialize()
        {
            if (Attribute.MinGetter != null)
            {
                getterMinValue = ValueResolver.Get<decimal>(Property, Attribute.MinGetter);
            }
            if (Attribute.MaxGetter != null)
            {
                getterMaxValue = ValueResolver.Get<decimal>(Property, Attribute.MaxGetter);
            }
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            decimal min = getterMinValue != null ? getterMinValue.GetValue() : (decimal)Attribute.Min;
            decimal max = getterMaxValue != null ? getterMaxValue.GetValue() : (decimal)Attribute.Max;

            if (getterMinValue != null && getterMinValue.ErrorMessage != null)
            {
                SirenixEditorGUI.ErrorMessageBox(getterMinValue.ErrorMessage);
            }
            if (getterMaxValue != null && getterMaxValue.ErrorMessage != null)
            {
                SirenixEditorGUI.ErrorMessageBox(getterMaxValue.ErrorMessage);
            }

            EditorGUI.BeginChangeCheck();
            float value = SirenixEditorFields.RangeFloatField(label, (float)ValueEntry.SmartValue, (float)Math.Min(min, max), (float)Math.Max(min, max));
            if (EditorGUI.EndChangeCheck())
            {
                ValueEntry.SmartValue = (decimal)value;
            }
        }
    }

    /// <summary>
    /// Draws short properties marked with <see cref="PropertyRangeAttribute"/>.
    /// </summary>
    /// <seealso cref="PropertyRangeAttribute"/>
    /// <seealso cref="MinValueAttribute"/>
    /// <seealso cref="MaxValueAttribute"/>
    /// <seealso cref="MinMaxSliderAttribute"/>
    /// <seealso cref="DelayedAttribute"/>
    /// <seealso cref="WrapAttribute"/>
    public sealed class PropertyRangeAttributeInt16Drawer : OdinAttributeDrawer<PropertyRangeAttribute, short>
    {
        private ValueResolver<short> getterMinValue;
        private ValueResolver<short> getterMaxValue;

        /// <summary>
        /// Initialized the drawer.
        /// </summary>
        protected override void Initialize()
        {
            if (Attribute.MinGetter != null)
            {
                getterMinValue = ValueResolver.Get<short>(Property, Attribute.MinGetter);
            }
            if (Attribute.MaxGetter != null)
            {
                getterMaxValue = ValueResolver.Get<short>(Property, Attribute.MaxGetter);
            }
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            short min = getterMinValue != null ? getterMinValue.GetValue() : (short)Attribute.Min;
            short max = getterMaxValue != null ? getterMaxValue.GetValue() : (short)Attribute.Max;

            if (getterMinValue != null && getterMinValue.ErrorMessage != null)
            {
                SirenixEditorGUI.ErrorMessageBox(getterMinValue.ErrorMessage);
            }
            if (getterMaxValue != null && getterMaxValue.ErrorMessage != null)
            {
                SirenixEditorGUI.ErrorMessageBox(getterMaxValue.ErrorMessage);
            }

            EditorGUI.BeginChangeCheck();
            int value = SirenixEditorFields.RangeIntField(label, ValueEntry.SmartValue, Mathf.Min(min, max), Mathf.Max(min, max));
            if (EditorGUI.EndChangeCheck())
            {
                if (value < short.MinValue)
                {
                    value = short.MinValue;
                }
                else if (value > short.MaxValue)
                {
                    value = short.MaxValue;
                }

                ValueEntry.SmartValue = (short)value;
            }
        }
    }

    /// <summary>
    /// Draws int properties marked with <see cref="PropertyRangeAttribute"/>.
    /// </summary>
    /// <seealso cref="PropertyRangeAttribute"/>
    /// <seealso cref="MinValueAttribute"/>
    /// <seealso cref="MaxValueAttribute"/>
    /// <seealso cref="MinMaxSliderAttribute"/>
    /// <seealso cref="DelayedAttribute"/>
    /// <seealso cref="WrapAttribute"/>
    public sealed class PropertyRangeAttributeInt32Drawer : OdinAttributeDrawer<PropertyRangeAttribute, int>
    {
        private ValueResolver<int> getterMinValue;
        private ValueResolver<int> getterMaxValue;

        /// <summary>
        /// Initialized the drawer.
        /// </summary>
        protected override void Initialize()
        {
            if (Attribute.MinGetter != null)
            {
                getterMinValue = ValueResolver.Get<int>(Property, Attribute.MinGetter);
            }
            if (Attribute.MaxGetter != null)
            {
                getterMaxValue = ValueResolver.Get<int>(Property, Attribute.MaxGetter);
            }
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            int min = getterMinValue != null ? getterMinValue.GetValue() : (int)Attribute.Min;
            int max = getterMaxValue != null ? getterMaxValue.GetValue() : (int)Attribute.Max;

            if (getterMinValue != null && getterMinValue.ErrorMessage != null)
            {
                SirenixEditorGUI.ErrorMessageBox(getterMinValue.ErrorMessage);
            }
            if (getterMaxValue != null && getterMaxValue.ErrorMessage != null)
            {
                SirenixEditorGUI.ErrorMessageBox(getterMaxValue.ErrorMessage);
            }

            EditorGUI.BeginChangeCheck();
            int value = SirenixEditorFields.RangeIntField(label, ValueEntry.SmartValue, Mathf.Min(min, max), Mathf.Max(min, max));
            if (EditorGUI.EndChangeCheck())
            {
                if (value < int.MinValue)
                {
                    value = int.MinValue;
                }
                else if (value > int.MaxValue)
                {
                    value = int.MaxValue;
                }

                ValueEntry.SmartValue = value;
            }
        }
    }

    /// <summary>
    /// Draws long properties marked with <see cref="PropertyRangeAttribute"/>.
    /// </summary>
    /// <seealso cref="PropertyRangeAttribute"/>
    /// <seealso cref="MinValueAttribute"/>
    /// <seealso cref="MaxValueAttribute"/>
    /// <seealso cref="MinMaxSliderAttribute"/>
    /// <seealso cref="DelayedAttribute"/>
    /// <seealso cref="WrapAttribute"/>
    public sealed class PropertyRangeAttributeInt64Drawer : OdinAttributeDrawer<PropertyRangeAttribute, long>
    {
        private ValueResolver<long> getterMinValue;
        private ValueResolver<long> getterMaxValue;

        /// <summary>
        /// Initialized the drawer.
        /// </summary>
        protected override void Initialize()
        {
            if (Attribute.MinGetter != null)
            {
                getterMinValue = ValueResolver.Get<long>(Property, Attribute.MinGetter);
            }
            if (Attribute.MaxGetter != null)
            {
                getterMaxValue = ValueResolver.Get<long>(Property, Attribute.MaxGetter);
            }
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            long min = getterMinValue != null ? getterMinValue.GetValue() : (long)Attribute.Min;
            long max = getterMaxValue != null ? getterMaxValue.GetValue() : (long)Attribute.Max;

            if (getterMinValue != null && getterMinValue.ErrorMessage != null)
            {
                SirenixEditorGUI.ErrorMessageBox(getterMinValue.ErrorMessage);
            }
            if (getterMaxValue != null && getterMaxValue.ErrorMessage != null)
            {
                SirenixEditorGUI.ErrorMessageBox(getterMaxValue.ErrorMessage);
            }

            EditorGUI.BeginChangeCheck();
            int value = SirenixEditorFields.RangeIntField(label, (int)ValueEntry.SmartValue, (int)Math.Min(min, max), (int)Math.Max(min, max));
            if (EditorGUI.EndChangeCheck())
            {
                ValueEntry.SmartValue = value;
            }
        }
    }

    /// <summary>
    /// Draws sbyte properties marked with <see cref="PropertyRangeAttribute"/>.
    /// </summary>
    /// <seealso cref="PropertyRangeAttribute"/>
    /// <seealso cref="MinValueAttribute"/>
    /// <seealso cref="MaxValueAttribute"/>
    /// <seealso cref="MinMaxSliderAttribute"/>
    /// <seealso cref="DelayedAttribute"/>
    /// <seealso cref="WrapAttribute"/>
    public sealed class PropertyRangeAttributeSByteDrawer : OdinAttributeDrawer<PropertyRangeAttribute, sbyte>
    {
        private ValueResolver<sbyte> getterMinValue;
        private ValueResolver<sbyte> getterMaxValue;

        /// <summary>
        /// Initialized the drawer.
        /// </summary>
        protected override void Initialize()
        {
            if (Attribute.MinGetter != null)
            {
                getterMinValue = ValueResolver.Get<sbyte>(Property, Attribute.MinGetter);
            }
            if (Attribute.MaxGetter != null)
            {
                getterMaxValue = ValueResolver.Get<sbyte>(Property, Attribute.MaxGetter);
            }
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            sbyte min = getterMinValue != null ? getterMinValue.GetValue() : (sbyte)Attribute.Min;
            sbyte max = getterMaxValue != null ? getterMaxValue.GetValue() : (sbyte)Attribute.Max;

            if (getterMinValue != null && getterMinValue.ErrorMessage != null)
            {
                SirenixEditorGUI.ErrorMessageBox(getterMinValue.ErrorMessage);
            }
            if (getterMaxValue != null && getterMaxValue.ErrorMessage != null)
            {
                SirenixEditorGUI.ErrorMessageBox(getterMaxValue.ErrorMessage);
            }

            EditorGUI.BeginChangeCheck();
            int value = SirenixEditorFields.RangeIntField(label, ValueEntry.SmartValue, Mathf.Min(min, max), Mathf.Max(min, max));
            if (EditorGUI.EndChangeCheck())
            {
                if (value < sbyte.MinValue)
                {
                    value = sbyte.MinValue;
                }
                else if (value > sbyte.MaxValue)
                {
                    value = sbyte.MaxValue;
                }

                ValueEntry.SmartValue = (sbyte)value;
            }
        }
    }

    /// <summary>
    /// Draws ushort properties marked with <see cref="PropertyRangeAttribute"/>.
    /// </summary>
    /// <seealso cref="PropertyRangeAttribute"/>
    /// <seealso cref="MinValueAttribute"/>
    /// <seealso cref="MaxValueAttribute"/>
    /// <seealso cref="MinMaxSliderAttribute"/>
    /// <seealso cref="DelayedAttribute"/>
    /// <seealso cref="WrapAttribute"/>
    public sealed class PropertyRangeAttributeUInt16Drawer : OdinAttributeDrawer<PropertyRangeAttribute, ushort>
    {
        private ValueResolver<ushort> getterMinValue;
        private ValueResolver<ushort> getterMaxValue;

        /// <summary>
        /// Initialized the drawer.
        /// </summary>
        protected override void Initialize()
        {
            if (Attribute.MinGetter != null)
            {
                getterMinValue = ValueResolver.Get<ushort>(Property, Attribute.MinGetter);
            }
            if (Attribute.MaxGetter != null)
            {
                getterMaxValue = ValueResolver.Get<ushort>(Property, Attribute.MaxGetter);
            }
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            ushort min = getterMinValue != null ? getterMinValue.GetValue() : (ushort)Attribute.Min;
            ushort max = getterMaxValue != null ? getterMaxValue.GetValue() : (ushort)Attribute.Max;

            if (getterMinValue != null && getterMinValue.ErrorMessage != null)
            {
                SirenixEditorGUI.ErrorMessageBox(getterMinValue.ErrorMessage);
            }
            if (getterMaxValue != null && getterMaxValue.ErrorMessage != null)
            {
                SirenixEditorGUI.ErrorMessageBox(getterMaxValue.ErrorMessage);
            }

            EditorGUI.BeginChangeCheck();
            int value = SirenixEditorFields.RangeIntField(label, ValueEntry.SmartValue, Mathf.Min(min, max), Mathf.Max(min, max));
            if (EditorGUI.EndChangeCheck())
            {
                if (value < ushort.MinValue)
                {
                    value = ushort.MinValue;
                }
                else if (value > ushort.MaxValue)
                {
                    value = ushort.MaxValue;
                }

                ValueEntry.SmartValue = (ushort)value;
            }
        }
    }

    /// <summary>
    /// Draws uint properties marked with <see cref="PropertyRangeAttribute"/>.
    /// </summary>
    /// <seealso cref="PropertyRangeAttribute"/>
    /// <seealso cref="MinValueAttribute"/>
    /// <seealso cref="MaxValueAttribute"/>
    /// <seealso cref="MinMaxSliderAttribute"/>
    /// <seealso cref="DelayedAttribute"/>
    /// <seealso cref="WrapAttribute"/>
    public sealed class PropertyRangeAttributeUInt32Drawer : OdinAttributeDrawer<PropertyRangeAttribute, uint>
    {
        private ValueResolver<uint> getterMinValue;
        private ValueResolver<uint> getterMaxValue;

        /// <summary>
        /// Initialized the drawer.
        /// </summary>
        protected override void Initialize()
        {
            if (Attribute.MinGetter != null)
            {
                getterMinValue = ValueResolver.Get<uint>(Property, Attribute.MinGetter);
            }
            if (Attribute.MaxGetter != null)
            {
                getterMaxValue = ValueResolver.Get<uint>(Property, Attribute.MaxGetter);
            }
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            uint min = getterMinValue != null ? getterMinValue.GetValue() : (uint)Attribute.Min;
            uint max = getterMaxValue != null ? getterMaxValue.GetValue() : (uint)Attribute.Max;

            if (getterMinValue != null && getterMinValue.ErrorMessage != null)
            {
                SirenixEditorGUI.ErrorMessageBox(getterMinValue.ErrorMessage);
            }
            if (getterMaxValue != null && getterMaxValue.ErrorMessage != null)
            {
                SirenixEditorGUI.ErrorMessageBox(getterMaxValue.ErrorMessage);
            }

            EditorGUI.BeginChangeCheck();
            int value = SirenixEditorFields.RangeIntField(label, (int)ValueEntry.SmartValue, (int)Mathf.Min(min, max), (int)Mathf.Max(min, max));
            if (EditorGUI.EndChangeCheck())
            {
                if (value < uint.MinValue)
                {
                    value = (int)uint.MinValue;
                }
                else
                {
                    ValueEntry.SmartValue = (uint)value;
                }

                ValueEntry.SmartValue = (uint)value;
            }
        }
    }

    /// <summary>
    /// Draws ulong properties marked with <see cref="PropertyRangeAttribute"/>.
    /// </summary>
    /// <seealso cref="PropertyRangeAttribute"/>
    /// <seealso cref="MinValueAttribute"/>
    /// <seealso cref="MaxValueAttribute"/>
    /// <seealso cref="MinMaxSliderAttribute"/>
    /// <seealso cref="DelayedAttribute"/>
    /// <seealso cref="WrapAttribute"/>
    public sealed class PropertyRangeAttributeUInt64Drawer : OdinAttributeDrawer<PropertyRangeAttribute, ulong>
    {
        private ValueResolver<ulong> getterMinValue;
        private ValueResolver<ulong> getterMaxValue;

        /// <summary>
        /// Initialized the drawer.
        /// </summary>
        protected override void Initialize()
        {
            if (Attribute.MinGetter != null)
            {
                getterMinValue = ValueResolver.Get<ulong>(Property, Attribute.MinGetter);
            }
            if (Attribute.MaxGetter != null)
            {
                getterMaxValue = ValueResolver.Get<ulong>(Property, Attribute.MaxGetter);
            }
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            ulong min = getterMinValue != null ? getterMinValue.GetValue() : (ulong)Attribute.Min;
            ulong max = getterMaxValue != null ? getterMaxValue.GetValue() : (ulong)Attribute.Max;

            if (getterMinValue != null && getterMinValue.ErrorMessage != null)
            {
                SirenixEditorGUI.ErrorMessageBox(getterMinValue.ErrorMessage);
            }
            if (getterMaxValue != null && getterMaxValue.ErrorMessage != null)
            {
                SirenixEditorGUI.ErrorMessageBox(getterMaxValue.ErrorMessage);
            }

            EditorGUI.BeginChangeCheck();
            int value = SirenixEditorFields.RangeIntField(label, (int)ValueEntry.SmartValue, (int)Mathf.Min(min, max), (int)Mathf.Max(min, max));
            if (EditorGUI.EndChangeCheck())
            {
                if (value < (int)ulong.MinValue)
                {
                    value = (int)ulong.MinValue;
                }
                else
                {
                    ValueEntry.SmartValue = (ulong)value;
                }

                ValueEntry.SmartValue = (ulong)value;
            }
        }
    }
}
#endif