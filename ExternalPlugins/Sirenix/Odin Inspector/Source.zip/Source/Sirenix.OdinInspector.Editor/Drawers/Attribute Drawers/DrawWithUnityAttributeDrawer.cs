//-----------------------------------------------------------------------
// <copyright file="DrawWithUnityAttributeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
#define ODIN_INSPECTOR
#define ODIN_INSPECTOR_3
#define ODIN_INSPECTOR_3_1
#define ODIN_INSPECTOR_3_2
#define ODIN_INSPECTOR_3_3
namespace Sirenix.OdinInspector.Editor
{
#pragma warning disable

    using Internal.UIToolkitIntegration;
    using System.Reflection;
    using UnityEditor;
    using UnityEditor.UIElements;
    using UnityEngine;
    using Utilities;
    using Utilities.Editor;

    /// <summary>
    /// Draws properties marked with <see cref="DrawWithUnityAttribute"/>.
    /// </summary>
    /// <seealso cref="RequireComponent"/>
    /// <seealso cref="OnInspectorGUIAttribute"/>
    /// <seealso cref="InlineEditorAttribute"/>
    /// <seealso cref="HideInInspector"/>
    [DrawerPriority(0, 0, 6000)]
    public class DrawWithUnityAttributeDrawer<T> : OdinAttributeDrawer<DrawWithUnityAttribute, T>, IUnityPropertyFieldDrawer
	{
        private OdinImGuiElement element;

        public bool WillDrawPropertyField => element != null;

        protected override void Initialize()
        {
            if (Attribute.PreferImGUI || !GeneralDrawerConfig.Instance.EnableUIToolkitSupport) return;

            var unityProperty = Property.Tree.GetUnityPropertyForPath(Property.Path, out _);

            if (unityProperty != null)
            {
                var propField = new PropertyField(unityProperty);

				ImguiElementUtils.RegisterSerializedPropertyChangeEventCallback(propField, prop =>
				{
                    if (ValueEntry.IsEditable && prop.serializedObject.targetObject is EmittedScriptableObject<T>)
                    {
                        var targetObjects = prop.serializedObject.targetObjects;

                        for (int i = 0; i < targetObjects.Length; i++)
                        {
                            EmittedScriptableObject<T> target = (EmittedScriptableObject<T>)targetObjects[i];
                            ValueEntry.Values[i] = target.GetValue();
                        }

                        ValueEntry.Values.ForceMarkDirty();
                    }
                });

                element = new OdinImGuiElement(propField, unityProperty);
                element.Bind(unityProperty.serializedObject);
            }
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            var entry = ValueEntry;

            FieldInfo fieldInfo;
            SerializedProperty unityProperty = entry.Property.Tree.GetUnityPropertyForPath(entry.Property.Path, out fieldInfo);

            if (unityProperty == null)
            {
                SirenixEditorGUI.ErrorMessageBox("Could not get a Unity SerializedProperty for the property '" + entry.Property.NiceName + "' of type '" + entry.TypeOfValue.GetNiceName() + "' at path '" + entry.Property.Path + "'.");
                return;
            }

            if (unityProperty.serializedObject.targetObject is EmittedScriptableObject<T>)
            {
                var targetObjects = unityProperty.serializedObject.targetObjects;

                for (int i = 0; i < targetObjects.Length; i++)
                {
                    EmittedScriptableObject<T> target = (EmittedScriptableObject<T>)targetObjects[i];
                    target.SetValue(entry.Values[i]);
                }

                unityProperty.serializedObject.Update();
                unityProperty = unityProperty.serializedObject.FindProperty(unityProperty.propertyPath);
            }

            if (GeneralDrawerConfig.Instance.EnableUIToolkitSupport && element != null)
            {
                ImguiElementUtils.EmbedVisualElementAndDrawItHere(element, label);
            }
            else
            {
                EditorGUI.BeginChangeCheck();
                EditorGUILayout.PropertyField(unityProperty, label ?? GUIContent.none, true);
                var changed = EditorGUI.EndChangeCheck();

                if (unityProperty.serializedObject.targetObject is EmittedScriptableObject<T>)
                {
                    unityProperty.serializedObject.ApplyModifiedPropertiesWithoutUndo();
                    var targetObjects = unityProperty.serializedObject.targetObjects;

                    for (int i = 0; i < targetObjects.Length; i++)
                    {
                        EmittedScriptableObject<T> target = (EmittedScriptableObject<T>)targetObjects[i];
                        entry.Values[i] = target.GetValue();
                    }

                    if (changed)
                    {
                        entry.Values.ForceMarkDirty();
                    }
                }
                else if (changed)
                {
                    Property.Tree.DelayActionUntilRepaint(() =>
                    {
                        var baseEntry = Property.BaseValueEntry;

                        for (int i = 0; i < baseEntry.ValueCount; i++)
                        {
                            (baseEntry as PropertyValueEntry).TriggerOnValueChanged(i);
                        }
                    });
                }
            }
        }

        public void Dispose()
        {
            if (element != null)
            {
                element.Unbind();
                element.RemoveFromHierarchy();
                element = null;
            }
        }
    }
}
#endif