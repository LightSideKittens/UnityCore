//-----------------------------------------------------------------------
// <copyright file="TypeFilterAttributeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
#define ODIN_INSPECTOR
#define ODIN_INSPECTOR_3
#define ODIN_INSPECTOR_3_1
#define ODIN_INSPECTOR_3_2
#define ODIN_INSPECTOR_3_3
namespace Sirenix.OdinInspector.Editor.Drawers
{
#pragma warning disable

    using OdinInspector;
    using Editor;
    using ValueResolvers;
    using Serialization;
    using Utilities;
    using Sirenix.Utilities.Editor;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using UnityEditor;
    using UnityEngine;

    /// <summary>
    /// Draws properties marked with <see cref="TypeFilterAttribute"/>.
    /// </summary>
    [DrawerPriority(0, 0, 2002)]
    public sealed class TypeFilterAttributeDrawer : OdinAttributeDrawer<TypeFilterAttribute>
    {
        private string error;
        private bool useSpecialListBehaviour;
        private Func<IEnumerable<ValueDropdownItem>> getValues;
        private Func<IEnumerable<object>> getSelection;
        private IEnumerable<object> result;
        private Dictionary<object, string> nameLookup;
        private ValueResolver<object> rawGetter;

        protected override bool CanDrawAttributeProperty(InspectorProperty property)
        {
            return property.ValueEntry != null;
        }

        /// <summary>
        /// Initializes this instance.
        /// </summary>
        protected override void Initialize()
        {
            rawGetter = ValueResolver.Get<object>(Property, Attribute.FilterGetter);

            error = rawGetter.ErrorMessage;
            useSpecialListBehaviour = (Property.ChildResolver as ICollectionResolver != null) && !Attribute.DrawValueNormally;
            getSelection = () => Property.ValueEntry.WeakValues.Cast<object>();
            getValues = () =>
            {
                var value = rawGetter.GetValue();

                return value == null ? null : (rawGetter.GetValue() as IEnumerable)
                    .Cast<object>()
                    .Where(x => x != null)
                    .Select(x =>
                    {
                        if (x is ValueDropdownItem)
                        {
                            return (ValueDropdownItem)x;
                        }

                        if (x is IValueDropdownItem)
                        {
                            var ix = x as IValueDropdownItem;
                            return new ValueDropdownItem(ix.GetText(), ix.GetValue());
                        }

                        return new ValueDropdownItem(null, x);
                    });
            };

            ReloadDropdownCollections();
        }

        private void ReloadDropdownCollections()
        {
            if (error != null)
            {
                return;
            }

            object first = null;
            var value = rawGetter.GetValue();
            if (value != null)
            {
                first = (rawGetter.GetValue() as IEnumerable).Cast<object>().FirstOrDefault();
            }

            var isNamedValueDropdownItems = first is IValueDropdownItem;

            if (isNamedValueDropdownItems)
            {
                var vals = getValues();
                nameLookup = new Dictionary<object, string>(new IValueDropdownEqualityComparer(true));
                foreach (var item in vals)
                {
                    nameLookup[item] = item.Text;
                }
            }
            else
            {
                nameLookup = null;
            }
        }

        private static IEnumerable<ValueDropdownItem> ToValueDropdowns(IEnumerable<object> query)
        {
            return query.Select(x =>
            {
                if (x is ValueDropdownItem)
                {
                    return (ValueDropdownItem)x;
                }

                if (x is IValueDropdownItem)
                {
                    var ix = x as IValueDropdownItem;
                    return new ValueDropdownItem(ix.GetText(), ix.GetValue());
                }

                return new ValueDropdownItem(null, x);
            });
        }

        /// <summary>
        /// Draws the property with GUILayout support. This method is called by DrawPropertyImplementation if the GUICallType is set to GUILayout, which is the default.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            if (Property.ValueEntry == null)
            {
                CallNextDrawer(label);
                return;
            }

            if (error != null)
            {
                SirenixEditorGUI.ErrorMessageBox(error);
                CallNextDrawer(label);
            }
            else if (useSpecialListBehaviour)
            {
                CollectionDrawerStaticInfo.NextCustomAddFunction = OpenSelector;
                CallNextDrawer(label);
                if (result != null)
                {
                    AddResult(result);
                    result = null;
                }
                CollectionDrawerStaticInfo.NextCustomAddFunction = null;
            }
            else
            {
                DrawDropdown(label);
            }
        }

        private void AddResult(IEnumerable<object> query)
        {
            if (query.Any() == false)
            {
                return;
            }

            if (useSpecialListBehaviour)
            {
                var changer = Property.ChildResolver as ICollectionResolver;

                foreach (var item in query)
                {
                    object[] arr = new object[Property.ParentValues.Count];

                    for (int i = 0; i < arr.Length; i++)
                    {
                        var type = item as Type;
                        if (type != null)
                        {
                            arr[i] = CreateInstance(type);
                        }
                    }

                    changer.QueueAdd(arr);
                }
            }
            else
            {
                var first = query.FirstOrDefault();
                var type = first as Type;
                for (int i = 0; i < Property.ValueEntry.WeakValues.Count; i++)
                {
                    if (type != null)
                    {
                        //this.Property.ValueEntry.WeakValues[i] = Activator.CreateInstance(t);
                        Property.ValueEntry.WeakValues[i] = CreateInstance(type);
                    }
                }
            }
        }

        private object CreateInstance(Type type)
        {
            if (Property.ValueEntry.SerializationBackend == SerializationBackend.Unity)
            {
                var value = UnitySerializationUtility.CreateDefaultUnityInitializedObject(type);
                if (value != null) return value;
            }
            
            if (type == typeof(string))
            {
                return "";
            }

            if (type.IsAbstract || type.IsInterface)
            {
                Debug.LogError("TypeFilter was asked to instantiate a value of type '" + type.GetNiceFullName() + "', but it is abstract or an interface and cannot be instantiated.");
                return null;
            }

            if (type.IsValueType || type.GetConstructor(Flags.InstanceAnyVisibility, null, Type.EmptyTypes, null) != null)
            {
                return Activator.CreateInstance(type);
            }

            return FormatterServices.GetUninitializedObject(type);
        }

        private void DrawDropdown(GUIContent label)
        {
            EditorGUI.BeginChangeCheck();

            IEnumerable<object> newResult = null;

            string valueName = GetCurrentValueName();

            if (Attribute.DrawValueNormally)
            {
                newResult = GenericSelector<object>.DrawSelectorDropdown(label, valueName, ShowSelector);
                CallNextDrawer(label);
            }
            else if (Property.Children.Count > 0)
            {
                Rect valRect;
                Property.State.Expanded = SirenixEditorGUI.Foldout(Property.State.Expanded, label, out valRect);
                newResult = GenericSelector<object>.DrawSelectorDropdown(valRect, valueName, ShowSelector);

                if (SirenixEditorGUI.BeginFadeGroup(this, Property.State.Expanded))
                {
                    EditorGUI.indentLevel++;
                    for (int i = 0; i < Property.Children.Count; i++)
                    {
                        var child = Property.Children[i];
                        child.Draw(child.Label);
                    }
                    EditorGUI.indentLevel--;
                }
                SirenixEditorGUI.EndFadeGroup();
            }
            else
            {
                newResult = GenericSelector<object>.DrawSelectorDropdown(label, valueName, ShowSelector);
            }

            if (EditorGUI.EndChangeCheck())
            {
                if (newResult != null)
                {
                    AddResult(newResult);
                }
            }
        }

        private void OpenSelector()
        {
            ReloadDropdownCollections();
            var rect = new Rect(Event.current.mousePosition, Vector2.zero);
            var selector = ShowSelector(rect);
            selector.SelectionConfirmed += x => result = x;
        }

        private OdinSelector<object> ShowSelector(Rect rect)
        {
            var selector = CreateSelector();

            rect.x = (int)rect.x;
            rect.y = (int)rect.y;
            rect.width = (int)rect.width;
            rect.height = (int)rect.height;

            selector.ShowInPopup(rect, new Vector2(0, 0));
            return selector;
        }

        private GenericSelector<object> CreateSelector()
        {
            var query = getValues();
            if (query == null)
            {
                query = Enumerable.Empty<ValueDropdownItem>();
            }

            var enableSearch = query.Take(10).Count() == 10;
            var selector = new GenericSelector<object>(Attribute.DropdownTitle, false, query.Select(x => new GenericSelectorItem<object>(x.Text, x.Value)));

            selector.CheckboxToggle = false;
            selector.EnableSingleClickToSelect();

            selector.SelectionTree.Config.DrawSearchToolbar = enableSearch;

            IEnumerable<object> selection = Enumerable.Empty<object>();

            if (!useSpecialListBehaviour)
            {
                selection = getSelection();
            }

            selection = selection.Select(x => (x == null ? null : x.GetType()) as object);
            selector.SetSelection(selection);
            selector.SelectionTree.EnumerateTree().AddThumbnailIcons(true);

            return selector;
        }

        private string GetCurrentValueName()
        {
            if (!EditorGUI.showMixedValue)
            {
                var weakValue = Property.ValueEntry.WeakSmartValue;

                string name = null;
                if (nameLookup != null && weakValue != null)
                {
                    nameLookup.TryGetValue(weakValue, out name);
                }

                if (weakValue != null)
                {
                    weakValue = weakValue.GetType();
                }

                return new GenericSelectorItem<object>(name, weakValue).GetNiceName();
            }
            else
            {
                return SirenixEditorGUI.MixedValueDashChar;
            }
        }
    }
}
#endif