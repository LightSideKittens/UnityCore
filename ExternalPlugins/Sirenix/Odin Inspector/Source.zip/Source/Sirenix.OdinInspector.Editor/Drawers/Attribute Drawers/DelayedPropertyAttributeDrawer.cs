//-----------------------------------------------------------------------
// <copyright file="DelayedPropertyAttributeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
#define ODIN_INSPECTOR
#define ODIN_INSPECTOR_3
#define ODIN_INSPECTOR_3_1
#define ODIN_INSPECTOR_3_2
#define ODIN_INSPECTOR_3_3
namespace Sirenix.OdinInspector.Editor.Drawers
{
#pragma warning disable

    using Utilities;
    using Sirenix.Utilities.Editor;
    using UnityEditor;
    using UnityEngine;

    /// <summary>
    /// Draws char properties marked with <see cref="DelayedPropertyAttribute"/>.
    /// </summary>
    public sealed class DelayedPropertyAttributeCharDrawer : OdinAttributeDrawer<DelayedPropertyAttribute, char>
    {
        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            //this.ValueEntry.SmartValue = SirenixEditorGUI.DynamicPrimitiveField(label, this.ValueEntry.SmartValue, GUILayoutOptions.MinWidth(0));
            EditorGUI.BeginChangeCheck();
            string s = new string(ValueEntry.SmartValue, 1);
            s = SirenixEditorFields.DelayedTextField(label, s, GUILayoutOptions.MinWidth(0));

            if (EditorGUI.EndChangeCheck() && s.Length > 0)
            {
                ValueEntry.SmartValue = s[0];
            }
        }
    }

    /// <summary>
    /// Draws string properties marked with <see cref="DelayedPropertyAttribute"/>.
    /// </summary>
    public sealed class DelayedPropertyAttributeStringDrawer : OdinAttributeDrawer<DelayedPropertyAttribute, string>
    {
        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            ValueEntry.SmartValue = SirenixEditorFields.DelayedTextField(label, ValueEntry.SmartValue, GUILayoutOptions.MinWidth(0));
        }
    }

    /// <summary>
    /// Draws sbyte properties marked with <see cref="DelayedPropertyAttribute"/>.
    /// </summary>
    public sealed class DelayedPropertyAttributeSByteDrawer : OdinAttributeDrawer<DelayedPropertyAttribute, sbyte>
    {
        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            int value = SirenixEditorFields.DelayedIntField(label, ValueEntry.SmartValue, GUILayoutOptions.MinWidth(0));

            if (value < sbyte.MinValue)
            {
                value = sbyte.MinValue;
            }
            else if (value > sbyte.MaxValue)
            {
                value = sbyte.MaxValue;
            }

            ValueEntry.SmartValue = (sbyte)value;
        }
    }

    /// <summary>
    /// Draws byte properties marked with <see cref="DelayedPropertyAttribute"/>.
    /// </summary>
    public sealed class DelayedPropertyAttributeByteDrawer : OdinAttributeDrawer<DelayedPropertyAttribute, byte>
    {
        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            int value = SirenixEditorFields.DelayedIntField(label, ValueEntry.SmartValue, GUILayoutOptions.MinWidth(0));

            if (value < byte.MinValue)
            {
                value = byte.MinValue;
            }
            else if (value > byte.MaxValue)
            {
                value = byte.MaxValue;
            }

            ValueEntry.SmartValue = (byte)value;
        }
    }

    /// <summary>
    /// Draws short properties marked with <see cref="DelayedPropertyAttribute"/>.
    /// </summary>
    public sealed class DelayedPropertyAttributeInt16Drawer : OdinAttributeDrawer<DelayedPropertyAttribute, short>
    {
        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            int value = SirenixEditorFields.DelayedIntField(label, ValueEntry.SmartValue, GUILayoutOptions.MinWidth(0));

            if (value < short.MinValue)
            {
                value = short.MinValue;
            }
            else if (value > short.MaxValue)
            {
                value = short.MaxValue;
            }

            ValueEntry.SmartValue = (short)value;
        }
    }

    /// <summary>
    /// Draws ushort properties marked with <see cref="DelayedPropertyAttribute"/>.
    /// </summary>
    public sealed class DelayedPropertyAttributeUInt16Drawer : OdinAttributeDrawer<DelayedPropertyAttribute, ushort>
    {
        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            int value = SirenixEditorFields.DelayedIntField(label, ValueEntry.SmartValue, GUILayoutOptions.MinWidth(0));

            if (value < ushort.MinValue)
            {
                value = ushort.MinValue;
            }
            else if (value > ushort.MaxValue)
            {
                value = ushort.MaxValue;
            }

            ValueEntry.SmartValue = (ushort)value;
        }
    }

    /// <summary>
    /// Draws int properties marked with <see cref="DelayedPropertyAttribute"/>.
    /// </summary>
    public sealed class DelayedPropertyAttributeInt32Drawer : OdinAttributeDrawer<DelayedPropertyAttribute, int>
    {
        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            ValueEntry.SmartValue = SirenixEditorFields.DelayedIntField(label, ValueEntry.SmartValue, GUILayoutOptions.MinWidth(0));
        }
    }

    /// <summary>
    /// Draws uint properties marked with <see cref="DelayedPropertyAttribute"/>.
    /// </summary>
    public sealed class DelayedPropertyAttributeUInt32Drawer : OdinAttributeDrawer<DelayedPropertyAttribute, uint>
    {
        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            long value = SirenixEditorFields.DelayedLongField(label, ValueEntry.SmartValue, GUILayoutOptions.MinWidth(0));

            if (value < uint.MinValue)
            {
                value = uint.MinValue;
            }
            else if (value > uint.MaxValue)
            {
                value = uint.MaxValue;
            }

            ValueEntry.SmartValue = (uint)value;
        }
    }

    /// <summary>
    /// Draws long properties marked with <see cref="DelayedPropertyAttribute"/>.
    /// </summary>
    public sealed class DelayedPropertyAttributeInt64Drawer : OdinAttributeDrawer<DelayedPropertyAttribute, long>
    {
        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            ValueEntry.SmartValue = SirenixEditorFields.DelayedLongField(label, ValueEntry.SmartValue, GUILayoutOptions.MinWidth(0));
        }
    }

    /// <summary>
    /// Draws ulong properties marked with <see cref="DelayedPropertyAttribute"/>.
    /// </summary>
    public sealed class DelayedPropertyAttributeUInt64Drawer : OdinAttributeDrawer<DelayedPropertyAttribute, ulong>
    {
        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            ulong value = ValueEntry.SmartValue;
            string str = value.ToString();

            str = label == null ?
                EditorGUILayout.DelayedTextField(str, GUILayoutOptions.MinWidth(0)) :
                EditorGUILayout.DelayedTextField(label, str, GUILayoutOptions.MinWidth(0));

            if (GUI.changed && ulong.TryParse(str, out value))
            {
                ValueEntry.SmartValue = value;
            }
        }
    }

    /// <summary>
    /// Draws float properties marked with <see cref="DelayedPropertyAttribute"/>.
    /// </summary>
    public sealed class DelayedPropertyAttributeFloatDrawer : OdinAttributeDrawer<DelayedPropertyAttribute, float>
    {
        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            ValueEntry.SmartValue = SirenixEditorFields.DelayedFloatField(label, ValueEntry.SmartValue, GUILayoutOptions.MinWidth(0));
        }
    }

    /// <summary>
    /// Draws double properties marked with <see cref="DelayedPropertyAttribute"/>.
    /// </summary>
    public sealed class DelayedPropertyAttributeDoubleDrawer : OdinAttributeDrawer<DelayedPropertyAttribute, double>
    {
        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            ValueEntry.SmartValue = SirenixEditorFields.DelayedDoubleField(label, ValueEntry.SmartValue, GUILayoutOptions.MinWidth(0));
        }
    }

    /// <summary>
    /// Draws decimal properties marked with <see cref="DelayedPropertyAttribute"/>.
    /// </summary>
    public sealed class DelayedPropertyAttributeDecimalDrawer : OdinAttributeDrawer<DelayedPropertyAttribute, decimal>
    {
        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            decimal value = ValueEntry.SmartValue;
            string str = value.ToString();

            str = SirenixEditorFields.DelayedTextField(label, str, GUILayoutOptions.MinWidth(0));

            if (GUI.changed && decimal.TryParse(str, out value))
            {
                ValueEntry.SmartValue = value;
            }
        }
    }
}
#endif