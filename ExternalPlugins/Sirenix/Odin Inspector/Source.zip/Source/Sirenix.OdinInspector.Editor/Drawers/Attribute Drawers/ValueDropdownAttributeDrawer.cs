//-----------------------------------------------------------------------
// <copyright file="ValueDropdownAttributeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
#define ODIN_INSPECTOR
#define ODIN_INSPECTOR_3
#define ODIN_INSPECTOR_3_1
#define ODIN_INSPECTOR_3_2
#define ODIN_INSPECTOR_3_3
namespace Sirenix.OdinInspector.Editor.Drawers
{
#pragma warning disable

    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using OdinInspector;
    using Editor;
    using ValueResolvers;
    using Serialization;
    using Utilities;
    using Sirenix.Utilities.Editor;
    using UnityEditor;
    using UnityEngine;
    using SerializationUtility = Serialization.SerializationUtility;

    /// <summary>
    /// Draws properties marked with <see cref="ValueDropdownAttribute"/>.
    /// </summary>
    /// <seealso cref="ValueDropdownAttribute"/>
    /// <seealso cref="ValueDropdownItem{T}"/>
    /// <summary>
    /// Draws the property.
    /// </summary>
    [DrawerPriority(0, 0, 2002)]
    public sealed class ValueDropdownAttributeDrawer : OdinAttributeDrawer<ValueDropdownAttribute>
    {
        private string error;
        private GUIContent label;
        private bool isList;
        private bool isListElement;
        private Func<IEnumerable<ValueDropdownItem>> getValues;
        private Func<IEnumerable<object>> getSelection;
        private IEnumerable<object> result;
        private bool enableMultiSelect;
        private Dictionary<object, string> nameLookup;
        private ValueResolver<object> rawGetter;
        private LocalPersistentContext<bool> isToggled;
        //private object rawPrevGettedValue = null;
        //private int rawPrevGettedValueCount = 0;

        /// <summary>
        /// Initializes this instance.
        /// </summary>
        protected override void Initialize()
        {
            rawGetter = ValueResolver.Get<object>(Property, Attribute.ValuesGetter);
            isToggled = this.GetPersistentValue("Toggled", SirenixEditorGUI.ExpandFoldoutByDefault);

            error = rawGetter.ErrorMessage;
            isList = Property.ChildResolver is ICollectionResolver;
            isListElement = Property.Parent != null && Property.Parent.ChildResolver is ICollectionResolver;
            getSelection = () => Property.ValueEntry.WeakValues.Cast<object>();
            getValues = () =>
            {
                var value = rawGetter.GetValue();

                return value == null ? null : (value as IEnumerable)
                    .Cast<object>()
                    .Where(x => x != null)
                    .Select(x =>
                    {
                        if (x is ValueDropdownItem)
                        {
                            return (ValueDropdownItem)x;
                        }

                        if (x is IValueDropdownItem)
                        {
                            var ix = x as IValueDropdownItem;
                            return new ValueDropdownItem(ix.GetText(), ix.GetValue());
                        }

                        return new ValueDropdownItem(null, x);
                    });
            };

            ReloadDropdownCollections();
        }

        private void ReloadDropdownCollections()
        {
            if (error != null)
            {
                return;
            }

            object first = null;
            var value = rawGetter.GetValue();
            if (value != null)
            {
                first = (value as IEnumerable).Cast<object>().FirstOrDefault();
            }

            var isNamedValueDropdownItems = first is IValueDropdownItem;

            if (isNamedValueDropdownItems)
            {
                var vals = getValues();
                nameLookup = new Dictionary<object, string>(new IValueDropdownEqualityComparer(false));
                foreach (var item in vals)
                {
                    nameLookup[item] = item.Text;
                }
            }
            else
            {
                nameLookup = null;
            }
        }

        private static IEnumerable<ValueDropdownItem> ToValueDropdowns(IEnumerable<object> query)
        {
            return query.Select(x =>
            {
                if (x is ValueDropdownItem)
                {
                    return (ValueDropdownItem)x;
                }

                if (x is IValueDropdownItem)
                {
                    var ix = x as IValueDropdownItem;
                    return new ValueDropdownItem(ix.GetText(), ix.GetValue());
                }

                return new ValueDropdownItem(null, x);
            });
        }

        /// <summary>
        /// Draws the property with GUILayout support. This method is called by DrawPropertyImplementation if the GUICallType is set to GUILayout, which is the default.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            this.label = label;

            if (Property.ValueEntry == null)
            {
                CallNextDrawer(label);
                return;
            }

            if (error != null)
            {
                SirenixEditorGUI.ErrorMessageBox(error);
                CallNextDrawer(label);
            }
            else if (isList)
            {
                if (Attribute.DisableListAddButtonBehaviour)
                {
                    CallNextDrawer(label);
                }
                else
                {
                    var oldSelector = CollectionDrawerStaticInfo.NextCustomAddFunction;
                    CollectionDrawerStaticInfo.NextCustomAddFunction = OpenSelector;
                    CallNextDrawer(label);
                    if (result != null)
                    {
                        AddResult(result);
                        result = null;
                    }
                    CollectionDrawerStaticInfo.NextCustomAddFunction = oldSelector;
                }
            }
            else
            {
                if (Attribute.DrawDropdownForListElements || !isListElement)
                {
                    DrawDropdown();
                }
                else
                {
                    CallNextDrawer(label);
                }
            }
        }

        private void AddResult(IEnumerable<object> query)
        {
            if (isList)
            {
                var changer = Property.ChildResolver as ICollectionResolver;

                if (enableMultiSelect)
                {
                    changer.QueueClear();
                }

                foreach (var item in query)
                {
                    object[] arr = new object[Property.ParentValues.Count];

                    for (int i = 0; i < arr.Length; i++)
                    {
                        if (Attribute.CopyValues)
                        {
                            arr[i] = SerializationUtility.CreateCopy(item);
                        }
                        else
                        {
                            arr[i] = item;
                        }
                    }

                    changer.QueueAdd(arr);
                }
            }
            else
            {
                var first = query.FirstOrDefault();
                for (int i = 0; i < Property.ValueEntry.WeakValues.Count; i++)
                {
                    if (Attribute.CopyValues)
                    {
                        Property.ValueEntry.WeakValues[i] = SerializationUtility.CreateCopy(first);
                    }
                    else
                    {
                        Property.ValueEntry.WeakValues[i] = first;
                    }
                }
            }
        }

        private void DrawDropdown()
        {
            IEnumerable<object> newResult = null;

            //if (this.Attribute.InlineSelector)
            //{
            //    bool recreateBecauseOfListChange = false;

            //    if (Event.current.type == EventType.Layout)
            //    {
            //        var _newCol = this.rawGetter.GetValue();
            //        if (_newCol != this.rawPrevGettedValue)
            //        {
            //            this.ReloadDropdownCollections();
            //            recreateBecauseOfListChange = true;
            //        }

            //        var iList = _newCol as IList;
            //        if (iList != null)
            //        {
            //            if (iList.Count != this.rawPrevGettedValueCount)
            //            {
            //                this.ReloadDropdownCollections();
            //                recreateBecauseOfListChange = true;
            //            }

            //            this.rawPrevGettedValueCount = iList.Count;
            //        }

            //        this.rawPrevGettedValue = _newCol;
            //    }

            //    if (this.inlineSelector == null || recreateBecauseOfListChange)
            //    {
            //        this.inlineSelector = this.CreateSelector();
            //        this.inlineSelector.SelectionChanged += (x) =>
            //        {
            //            this.nextResult = x;
            //        };
            //    }

            //    this.inlineSelector.OnInspectorGUI();

            //    if (this.nextResult != null)
            //    {
            //        newResult = this.nextResult;
            //        this.nextResult = null;
            //    }
            //}
            //else if (this.Attribute.AppendNextDrawer && !this.isList)
            if (Attribute.AppendNextDrawer && !isList)
            {
                GUILayout.BeginHorizontal();
                {
                    var width = 15f;
                    if (label != null)
                    {
                        width += GUIHelper.BetterLabelWidth;
                    }

                    var t = GUIHelper.TempContent("");
                    if (Property.Info.TypeOfValue == typeof(Type))
                        t.image = GUIHelper.GetAssetThumbnail(null, Property.ValueEntry.WeakSmartValue as Type, false);

                    newResult = GenericSelector<object>.DrawSelectorDropdown(label, t, ShowSelector, !Attribute.OnlyChangeValueOnConfirm, GUIStyle.none, GUILayoutOptions.Width(width));
                    if (Event.current.type == EventType.Repaint)
                    {
                        var btnRect = GUILayoutUtility.GetLastRect().AlignRight(15);
                        btnRect.y += 4;
                        SirenixGUIStyles.PaneOptions.Draw(btnRect, GUIContent.none, 0);
                    }

                    GUILayout.BeginVertical();
                    bool disable = Attribute.DisableGUIInAppendedDrawer;
                    if (disable) GUIHelper.PushGUIEnabled(false);
                    CallNextDrawer(null);
                    if (disable) GUIHelper.PopGUIEnabled();
                    GUILayout.EndVertical();
                }
                GUILayout.EndHorizontal();
            }
            else
            {
                var valueName = GUIHelper.TempContent(GetCurrentValueName());

                if (Property.Info.TypeOfValue == typeof(Type))
                    valueName.image = GUIHelper.GetAssetThumbnail(null, Property.ValueEntry.WeakSmartValue as Type, false);

                if (Attribute.HideChildProperties == false && Property.Children.Count > 0)
                {
                    Rect valRect;
                    isToggled.Value = SirenixEditorGUI.Foldout(isToggled.Value, label, out valRect);
                    newResult = GenericSelector<object>.DrawSelectorDropdown(valRect, valueName, ShowSelector, !Attribute.OnlyChangeValueOnConfirm);

                    if (SirenixEditorGUI.BeginFadeGroup(this, isToggled.Value))
                    {
                        EditorGUI.indentLevel++;
                        for (int i = 0; i < Property.Children.Count; i++)
                        {
                            var child = Property.Children[i];
                            child.Draw(child.Label);
                        }
                        EditorGUI.indentLevel--;
                    }
                    SirenixEditorGUI.EndFadeGroup();
                }
                else
                {
                    newResult = GenericSelector<object>.DrawSelectorDropdown(label, valueName, ShowSelector, !Attribute.OnlyChangeValueOnConfirm);
                }
            }

            if (newResult != null && newResult.Any())
            {
                AddResult(newResult);
            }
        }

        private void OpenSelector()
        {
            ReloadDropdownCollections();
            var rect = new Rect(Event.current.mousePosition, Vector2.zero);
            var selector = ShowSelector(rect);
            selector.SelectionConfirmed += x => result = x;
        }

        private OdinSelector<object> ShowSelector(Rect rect)
        {
            var selector = CreateSelector();

            rect.x = (int)rect.x;
            rect.y = (int)rect.y;
            rect.width = (int)rect.width;
            rect.height = (int)rect.height;

            if (Attribute.AppendNextDrawer && !isList)
            {
                rect.xMax = GUIHelper.GetCurrentLayoutRect().xMax;
            }

            selector.ShowInPopup(rect, new Vector2(Attribute.DropdownWidth, Attribute.DropdownHeight));
            return selector;
        }

        private GenericSelector<object> CreateSelector()
        {
            bool isUniqueList = Attribute.IsUniqueList; // /*(this.Property.ChildResolver is IOrderedCollectionResolver) == false ||*/ (this.Attribute.IsUniqueList || this.Attribute.ExcludeExistingValuesInList);
            var query = getValues() ?? Enumerable.Empty<ValueDropdownItem>();

            var isEmpty = query.Any() == false;

            if (!isEmpty)
            {
                if (isList && Attribute.ExcludeExistingValuesInList || (isListElement && isUniqueList))
                {
                    var list = query.ToList();
                    var listProperty = Property.FindParent(x => (x.ChildResolver as ICollectionResolver) != null, true);
                    var comparer = new IValueDropdownEqualityComparer(false);

                    listProperty.ValueEntry.WeakValues.Cast<IEnumerable>()
                        .SelectMany(x => x.Cast<object>())
                        .ForEach(x =>
                        {
                            list.RemoveAll(c => comparer.Equals(c, x));
                        });

                    query = list;
                }

                // Update item names in the look up table in case the collection has changed.
                if (nameLookup != null)
                {
                    foreach (var item in query)
                    {
                        if (item.Value != null)
                        {
                            nameLookup[item.Value] = item.Text;
                        }
                    }
                }
            }

            var enableSearch = Attribute.NumberOfItemsBeforeEnablingSearch == 0 || (query != null && query.Take(Attribute.NumberOfItemsBeforeEnablingSearch).Count() == Attribute.NumberOfItemsBeforeEnablingSearch);

            var selector = new GenericSelector<object>(Attribute.DropdownTitle, false, query.Select(x => new GenericSelectorItem<object>(x.Text, x.Value)));

            enableMultiSelect = isList && isUniqueList && !Attribute.ExcludeExistingValuesInList;

            if (Attribute.FlattenTreeView)
            {
                selector.FlattenedTree = true;
            }

            if (isList && !Attribute.ExcludeExistingValuesInList && isUniqueList)
            {
                selector.CheckboxToggle = true;
            }
            else if (Attribute.DoubleClickToConfirm == false && !enableMultiSelect)
            {
                selector.EnableSingleClickToSelect();
            }

            if (isList && enableMultiSelect)
            {
                selector.SelectionTree.Selection.SupportsMultiSelect = true;
                selector.DrawConfirmSelectionButton = true;
            }

            selector.SelectionTree.Config.DrawSearchToolbar = enableSearch;

            var selection = Enumerable.Empty<object>();

            if (!isList)
            {
                selection = getSelection();
            }
            else if (enableMultiSelect)
            {
                selection = getSelection().SelectMany(x => (x as IEnumerable).Cast<object>());
            }

            selector.SetSelection(selection);
            selector.SelectionTree.EnumerateTree().AddThumbnailIcons(true);

            if (Attribute.ExpandAllMenuItems)
            {
                selector.SelectionTree.EnumerateTree(x => x.Toggled = true);
            }

            if (Attribute.SortDropdownItems)
            {
                selector.SelectionTree.SortMenuItemsByName();
            }

            return selector;
        }

        private string GetCurrentValueName()
        {
            if (!EditorGUI.showMixedValue)
            {
                var weakValue = Property.ValueEntry.WeakSmartValue;

                string name = null;
                if (nameLookup != null && weakValue != null)
                {
                    nameLookup.TryGetValue(weakValue, out name);
                }

                return new GenericSelectorItem<object>(name, weakValue).GetNiceName();
            }
            else
            {
                return SirenixEditorGUI.MixedValueDashChar;
            }
        }
    }

    internal class IValueDropdownEqualityComparer : IEqualityComparer<object>
    {
        private bool isTypeLookup;

        public IValueDropdownEqualityComparer(bool isTypeLookup)
        {
            this.isTypeLookup = isTypeLookup;
        }

        public new bool Equals(object x, object y)
        {
            if (x is ValueDropdownItem)
            {
                x = ((ValueDropdownItem)x).Value;
            }

            if (y is ValueDropdownItem)
            {
                y = ((ValueDropdownItem)y).Value;
            }

            if (EqualityComparer<object>.Default.Equals(x, y))
            {
                return true;
            }

            if ((x == null) != (y == null))
            {
                return false;
            }

            if (isTypeLookup)
            {
                var tx = x as Type ?? x.GetType();
                var ty = y as Type ?? y.GetType();

                if (tx == ty)
                {
                    return true;
                }
            }

            return false;
        }

        public int GetHashCode(object obj)
        {
            if (obj == null)
            {
                return -1;
            }

            if (obj is ValueDropdownItem)
            {
                obj = ((ValueDropdownItem)obj).Value;
            }

            if (obj == null)
            {
                return -1;
            }

            if (isTypeLookup)
            {
                var t = obj as Type ?? obj.GetType();
                return t.GetHashCode();
            }
            else
            {
                return obj.GetHashCode();
            }
        }
    }
}
#endif