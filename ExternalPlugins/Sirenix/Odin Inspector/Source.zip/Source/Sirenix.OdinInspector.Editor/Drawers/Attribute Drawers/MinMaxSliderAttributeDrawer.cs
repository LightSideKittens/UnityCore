//-----------------------------------------------------------------------
// <copyright file="MinMaxSliderAttributeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
#define ODIN_INSPECTOR
#define ODIN_INSPECTOR_3
#define ODIN_INSPECTOR_3_1
#define ODIN_INSPECTOR_3_2
#define ODIN_INSPECTOR_3_3
namespace Sirenix.OdinInspector.Editor.Drawers
{
#pragma warning disable

    using ValueResolvers;
    using Sirenix.Utilities.Editor;
    using UnityEditor;
    using UnityEngine;

    /// <summary>
    /// Draws Vector2 properties marked with <see cref="MinMaxSliderAttribute"/>.
    /// </summary>
    /// <seealso cref="MinMaxSliderAttribute"/>
    /// <seealso cref="MinValueAttribute"/>
    /// <seealso cref="MaxValueAttribute"/>
    /// <seealso cref="RangeAttribute"/>
    /// <seealso cref="DelayedAttribute"/>
    /// <seealso cref="WrapAttribute"/>
    public sealed class MinMaxSliderAttributeDrawer : OdinAttributeDrawer<MinMaxSliderAttribute, Vector2>
    {
        private ValueResolver<double> minGetter;
        private ValueResolver<double> maxGetter;
        private ValueResolver<Vector2> rangeGetter;

        protected override void Initialize()
        {
            if (Attribute.MinMaxValueGetter != null)
            {
                rangeGetter = ValueResolver.Get<Vector2>(Property, Attribute.MinMaxValueGetter, new Vector2(Attribute.MinValue, Attribute.MaxValue));
            }
            else
            {
                minGetter = ValueResolver.Get<double>(Property, Attribute.MinValueGetter, Attribute.MinValue);
                maxGetter = ValueResolver.Get<double>(Property, Attribute.MaxValueGetter, Attribute.MaxValue);
            }
        }

        protected override void DrawPropertyLayout(GUIContent label)
        {
            Vector2 range;

            if (rangeGetter != null)
                range = rangeGetter.GetValue();
            else
                range = new Vector2((float)minGetter.GetValue(), (float)maxGetter.GetValue());

            EditorGUI.BeginChangeCheck();
            var value = SirenixEditorFields.MinMaxSlider(label, ValueEntry.SmartValue, range, Attribute.ShowFields);
            if (EditorGUI.EndChangeCheck())
            {
                ValueEntry.SmartValue = value;
            }
        }
    }
}
#endif