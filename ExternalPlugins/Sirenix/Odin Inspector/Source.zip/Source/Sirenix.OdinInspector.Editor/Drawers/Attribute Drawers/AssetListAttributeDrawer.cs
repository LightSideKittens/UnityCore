//-----------------------------------------------------------------------
// <copyright file="AssetListAttributeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
#define ODIN_INSPECTOR
#define ODIN_INSPECTOR_3
#define ODIN_INSPECTOR_3_1
#define ODIN_INSPECTOR_3_2
#define ODIN_INSPECTOR_3_3
namespace Sirenix.OdinInspector.Editor.Drawers
{
#pragma warning disable

    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using Utilities;
    using Utilities.Editor;
    using UnityEditor;
    using UnityEngine;
    using System.Collections;
    using ValueResolvers;
    using Internal;

    /// <summary>
    /// Draws properties marked with <see cref="AssetListAttribute"/>.
    /// Displays a configurable list of assets, where each item can be enabled or disabled.
    /// </summary>
    /// <seealso cref="AssetListAttribute"/>
    /// <seealso cref="AssetsOnlyAttribute"/>
    /// <seealso cref="SceneObjectsOnlyAttribute"/>
    /// <seealso cref="RequiredAttribute"/>
    /// <seealso cref="ValidateInputAttribute"/>
    [DrawerPriority(DrawerPriorityLevel.AttributePriority)]
    public sealed class AssetListAttributeDrawer<TList, TElement> : OdinAttributeDrawer<AssetListAttribute, TList>, IDefinesGenericMenuItems, IDisposable where TList : IList<TElement> where TElement : UnityEngine.Object
    {
        private static readonly NamedValue[] customFilterMethodArgs = new NamedValue[]
        {
            new NamedValue("asset", typeof(TElement))
        };

        private AssetList assetList;
        private PropertyTree propertyTree;
        private InspectorProperty listProperty;

        protected override void Initialize()
        {
            var property = Property;
            var entry = ValueEntry;
            var attribute = Attribute;

            assetList = new AssetList();

            assetList.AutoPopulate = attribute.AutoPopulate;
            assetList.AssetNamePrefix = attribute.AssetNamePrefix;
            assetList.Tags = attribute.Tags != null ? attribute.Tags.Trim().Split(',').Select(i => i.Trim()).ToArray() : null;
            assetList.LayerNames = attribute.LayerNames != null ? attribute.LayerNames.Trim().Split(',').Select(i => i.Trim()).ToArray() : null;
            assetList.List = entry;
            assetList.CollectionResolver = property.ChildResolver as IOrderedCollectionResolver;
            assetList.Property = entry.Property;

            if (attribute.Path != null)
            {
                var path = attribute.Path.TrimStart('/', ' ').TrimEnd('/', ' ');
                path = attribute.Path.Trim('/', ' ');

                path = "Assets/" + path + "/";
                path = Application.dataPath + "/" + path;

                assetList.AssetsFolderLocation = new DirectoryInfo(path);

                path = attribute.Path.Trim('/', ' ');
                assetList.PrettyPath = "/" + path.TrimStart('/');
            }

            if (attribute.CustomFilterMethod != null)
            {
                assetList.CustomFilterMethod = ValueResolver.Get<bool>(Property, attribute.CustomFilterMethod, customFilterMethodArgs);
            }

            if (Event.current != null)
            {
                // We can get away with lag on load.
                assetList.MaxSearchDurationPrFrameInMS = 20;
                assetList.EnsureListPopulation();
            }

            assetList.MaxSearchDurationPrFrameInMS = 1;

            propertyTree = PropertyTree.Create(assetList);
            propertyTree.UpdateTree();

            listProperty = propertyTree.GetPropertyAtPath("toggleableAssets");
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            var property = Property;
            var entry = ValueEntry;
            var attribute = Attribute;

            if (property.ValueEntry.WeakSmartValue == null)
            {
                return;
            }

            propertyTree.GetRootProperty(0).Label = label;

            listProperty.State.Enabled = Property.State.Enabled;
            listProperty.State.Expanded = Property.State.Expanded;

            if (Event.current.type == EventType.Layout)
            {
                assetList.Property = entry.Property;
                assetList.EnsureListPopulation();
                assetList.SetToggleValues();
            }

            if (assetList.CustomFilterMethod != null && assetList.CustomFilterMethod.HasError)
            {
                assetList.CustomFilterMethod.DrawError();
            }

            assetList.Property = entry.Property;
            propertyTree.Draw(false);

            Property.State.Enabled = listProperty.State.Enabled;
            Property.State.Expanded = listProperty.State.Expanded;

            if (Event.current.type == EventType.Used)
            {
                assetList.UpdateList();
            }
        }

        /// <summary>
        /// Populates the generic menu for the property.
        /// </summary>
        public void PopulateGenericMenu(InspectorProperty property, GenericMenu genericMenu)
        {
            if (assetList == null)
            {
                return;
            }

            if (assetList.List.SmartValue.Count != assetList.ToggleableAssets.Count)
            {
                genericMenu.AddItem(new GUIContent("Include All"), false, () => { assetList.UpdateList(true); });
            }
            else
            {
                genericMenu.AddDisabledItem(new GUIContent("Include All"));
            }
        }

        public void Dispose()
        {
            if (propertyTree != null)
            {
                propertyTree.Dispose();
                propertyTree = null;
            }
        }

        [Serializable, ShowOdinSerializedPropertiesInInspector]
        private class AssetList
        {
            [HideInInspector]
            public bool AutoPopulate;

            [HideInInspector]
            public string AssetNamePrefix;

            [HideInInspector]
            public string[] LayerNames;

            [HideInInspector]
            public string[] Tags;

            [HideInInspector]
            public IPropertyValueEntry<TList> List;

            [HideInInspector]
            public IOrderedCollectionResolver CollectionResolver;

            [HideInInspector]
            public DirectoryInfo AssetsFolderLocation;

            [HideInInspector]
            public string PrettyPath;

            [HideInInspector]
            public ValueResolver<bool> CustomFilterMethod;

            [HideInInspector]
            public InspectorProperty Property;

            public List<ToggleableAsset> ToggleableAssets
            {
                get
                {
                    return toggleableAssets;
                }
            }

            [SerializeField]
            [ListDrawerSettings(IsReadOnly = true, DraggableItems = false, OnTitleBarGUI = "OnListTitlebarGUI", ShowItemCount = false)]
            [DisableContextMenu(true, true)]
            [HideReferenceObjectPicker]
            private List<ToggleableAsset> toggleableAssets = new List<ToggleableAsset>();

            [SerializeField]
            [HideInInspector]
            private HashSet<TElement> toggledAssets = new HashSet<TElement>();

            [SerializeField]
            [HideInInspector]
            private Dictionary<TElement, ToggleableAsset> toggleableAssetLookup = new Dictionary<TElement, ToggleableAsset>();

            [NonSerialized]
            public bool IsPopulated = false;

            [NonSerialized]
            public double MaxSearchDurationPrFrameInMS = 1;

            [NonSerialized]
            public int NumberOfResultsToSearch = 0;

            [NonSerialized]
            public int TotalSearchCount = 0;

            [NonSerialized]
            public int CurrentSearchingIndex = 0;

            [NonSerialized]
            private IEnumerator populateListRoutine;

            private IEnumerator PopulateListRoutine()
            {
                while (true)
                {
                    if (IsPopulated)
                    {
                        yield return null;
                        continue;
                    }

                    HashSet<UnityEngine.Object> seenObjects = new HashSet<UnityEngine.Object>();
                    toggleableAssets.Clear();
                    toggleableAssetLookup.Clear();

                    IEnumerable<AssetUtilities.AssetSearchResult> allAssets;
#pragma warning disable CS0618 // Type or member is obsolete
                    if (PrettyPath == null)
                    {
                        allAssets = AssetUtilities.GetAllAssetsOfTypeWithProgress(typeof(TElement), null);
                    }
                    else
                    {
                        allAssets = AssetUtilities.GetAllAssetsOfTypeWithProgress(typeof(TElement), "Assets/" + PrettyPath.TrimStart('/'));
                    }
#pragma warning restore CS0618 // Type or member is obsolete

                    int[] layers = LayerNames != null ? LayerNames.Select(l => LayerMask.NameToLayer(l)).ToArray() : null;

                    System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
                    sw.Start();

                    foreach (var p in allAssets)
                    {
                        if (sw.Elapsed.TotalMilliseconds > MaxSearchDurationPrFrameInMS)
                        {
                            NumberOfResultsToSearch = p.NumberOfResults;
                            CurrentSearchingIndex = p.CurrentIndex;

                            GUIHelper.RequestRepaint();
                            //this.SetToggleValues(startIndex);

                            yield return null;
                            sw.Reset();
                            sw.Start();
                        }

                        var asset = p.Asset;

                        if (asset != null && seenObjects.Add(asset))
                        {
                            var go = asset as Component != null ? (asset as Component).gameObject : asset as GameObject == null ? null : asset as GameObject;

                            var assetName = go == null ? asset.name : go.name;

                            if (AssetNamePrefix != null && assetName.StartsWith(AssetNamePrefix, StringComparison.InvariantCultureIgnoreCase) == false)
                            {
                                continue;
                            }

                            if (AssetsFolderLocation != null)
                            {
                                var path = new DirectoryInfo(Path.GetDirectoryName(Application.dataPath + "/" + AssetDatabase.GetAssetPath(asset)));
                                if (AssetsFolderLocation.HasSubDirectory(path) == false)
                                {
                                    continue;
                                }
                            }

                            if (LayerNames != null && go == null || Tags != null && go == null)
                            {
                                continue;
                            }

                            if (go != null && Tags != null && !Tags.Contains(go.tag))
                            {
                                continue;
                            }

                            if (go != null && LayerNames != null && !layers.Contains(go.layer))
                            {
                                continue;
                            }

                            if (toggleableAssetLookup.ContainsKey(asset as TElement))
                            {
                                continue;
                            }

                            if (CustomFilterMethod != null)
                            {
                                CustomFilterMethod.Context.NamedValues.Set("asset", asset);

                                if (!CustomFilterMethod.GetValue())
                                {
                                    continue;
                                }
                            }
                            
                            var toggleable = new ToggleableAsset(asset as TElement, AutoPopulate);

                            toggleableAssets.Add(toggleable);
                            toggleableAssetLookup.Add(asset as TElement, toggleable);
                        }
                    }

                    SetToggleValues();

                    IsPopulated = true;
                    GUIHelper.RequestRepaint();
                    yield return null;
                }
            }

            public void EnsureListPopulation()
            {
                if (Event.current.type == EventType.Layout)
                {
                    if (populateListRoutine == null)
                    {
                        populateListRoutine = PopulateListRoutine();
                    }

                    populateListRoutine.MoveNext();
                }
            }

            public void SetToggleValues(int startIndex = 0)
            {
                if (List.SmartValue == null)
                {
                    return;
                }

                for (int i = startIndex; i < toggleableAssets.Count; i++)
                {
                    if (toggleableAssets[i] == null || toggleableAssets[i].Object == null)
                    {
                        Rescan();
                        break;
                    }

                    toggleableAssets[i].Toggled = false;
                }

                for (int i = List.SmartValue.Count - 1; i >= startIndex; i--)
                {
                    var asset = List.SmartValue[i] as TElement;
                    if (asset == null)
                    {
                        CollectionResolver.QueueRemoveAt(i);
                    }
                    else
                    {
                        ToggleableAsset toggleable;
                        if (toggleableAssetLookup.TryGetValue(asset, out toggleable))
                        {
                            toggleable.Toggled = true;
                        }
                        else
                        {
                            if (IsPopulated)
                            {
                                CollectionResolver.QueueRemoveAt(i);
                            }
                        }
                    }
                }
            }

            public void Rescan()
            {
                IsPopulated = false;
            }

            private void OnListTitlebarGUI()
            {
                if (PrettyPath != null)
                {
                    GUILayout.Label(PrettyPath, SirenixGUIStyles.RightAlignedGreyMiniLabel);
                    SirenixEditorGUI.VerticalLineSeparator();
                }

                if (IsPopulated)
                {
                    GUILayout.Label(List.SmartValue.Count + " / " + toggleableAssets.Count, SirenixGUIStyles.CenteredGreyMiniLabel);
                }
                else
                {
                    GUILayout.Label("Scanning " + CurrentSearchingIndex + " / " + NumberOfResultsToSearch, SirenixGUIStyles.RightAlignedGreyMiniLabel);
                }
                bool disableGUI = !IsPopulated;

                if (disableGUI)
                {
                    GUIHelper.PushGUIEnabled(false);
                }

                if (SirenixEditorGUI.ToolbarButton(EditorIcons.Refresh) && IsPopulated)
                {
                    Rescan();
                }

                if (AssetUtilities.CanCreateNewAsset<TElement>())
                {
                    if (SirenixEditorGUI.ToolbarButton(SdfIconType.Plus) && IsPopulated)
                    {
                        string path = PrettyPath;
                        if (path == null)
                        {
                            var lastAsset = List.SmartValue.Count > 0 ? List.SmartValue[List.SmartValue.Count - 1] as TElement : null;
                            if (lastAsset == null)
                            {
                                var lastToggleable = toggleableAssets.LastOrDefault();
                                if (lastToggleable != null)
                                {
                                    lastAsset = lastToggleable.Object;
                                }
                            }
                            if (lastAsset != null)
                            {
                                path = AssetUtilities.GetAssetLocation(lastAsset);
                            }
                        }
#pragma warning disable CS0618 // Type or member is obsolete
                        AssetUtilities.CreateNewAsset<TElement>(path, null);
#pragma warning restore CS0618 // Type or member is obsolete
                        Rescan();
                    }
                }

                if (disableGUI)
                {
                    GUIHelper.PopGUIEnabled();
                }
            }

            public void UpdateList()
            {
                UpdateList(false);
            }

            public void UpdateList(bool includeAll)
            {
                if (List.SmartValue == null)
                {
                    return;
                }

                toggledAssets.Clear();
                for (int i = 0; i < toggleableAssets.Count; i++)
                {
                    if (includeAll || AutoPopulate || toggleableAssets[i].Toggled)
                    {
                        toggledAssets.Add(toggleableAssets[i].Object);
                    }
                }

                for (int i = List.SmartValue.Count - 1; i >= 0; i--)
                {
                    if (List.SmartValue[i] as TElement == null)
                    {
                        CollectionResolver.QueueRemoveAt(i);
                        Rescan();
                    }
                    else if (toggledAssets.Contains(List.SmartValue[i] as TElement) == false)
                    {
                        if (IsPopulated)
                        {
                            CollectionResolver.QueueRemoveAt(i);
                        }
                    }
                    else
                    {
                        toggledAssets.Remove(List.SmartValue[i] as TElement);
                    }
                }

                foreach (var asset in toggledAssets.GFIterator())
                {
                    CollectionResolver.QueueAdd(Enumerable.Repeat(asset, List.ValueCount).ToArray());
                }

                toggledAssets.Clear();
            }
        }

        [Serializable]
        private class ToggleableAsset
        {
            [HideInInspector]
            public bool AutoToggle;

            public bool Toggled;

            public TElement Object;

            public ToggleableAsset(TElement obj, bool autoToggle)
            {
                AutoToggle = autoToggle;
                Object = obj;
            }
        }

        private sealed class AssetInstanceDrawer : OdinValueDrawer<ToggleableAsset>
        {
            protected override void DrawPropertyLayout(GUIContent label)
            {
                var entry = ValueEntry;
                if (entry.SmartValue.AutoToggle)
                {
#pragma warning disable 0618 // Type or member is obsolete
                    OdinInternalEditorFields.UnityObjectField(null, entry.SmartValue.Object, entry.SmartValue.Object.GetType(), false, true);
#pragma warning restore 0618 // Type or member is obsolete
                }
                else
                {
                    var rect = GUILayoutUtility.GetRect(16, 16, GUILayoutOptions.ExpandWidth(true));
                    var toggleRect = new Rect(rect.x, rect.y, 16, 16);
                    var objectFieldRect = new Rect(rect.x + 20, rect.y, rect.width - 20, 16);

                    if (Event.current.type != EventType.Repaint)
                    {
                        toggleRect.x -= 5;
                        toggleRect.y -= 5;
                        toggleRect.width += 10;
                        toggleRect.height += 10;
                    }
                    var prevChanged = GUI.changed;

                    entry.SmartValue.Toggled = GUI.Toggle(toggleRect, entry.SmartValue.Toggled, "");

                    if (prevChanged != GUI.changed)
                    {
                        entry.ApplyChanges();
                    }

                    GUIHelper.PushGUIEnabled(entry.SmartValue.Toggled);

#pragma warning disable 0618 // Type or member is obsolete
                    OdinInternalEditorFields.UnityObjectField(objectFieldRect, null, entry.SmartValue.Object, entry.SmartValue.Object.GetType(), false, true);
#pragma warning restore 0618 // Type or member is obsolete

                    GUIHelper.PopGUIEnabled();
                }
            }
        }
    }
}
#endif