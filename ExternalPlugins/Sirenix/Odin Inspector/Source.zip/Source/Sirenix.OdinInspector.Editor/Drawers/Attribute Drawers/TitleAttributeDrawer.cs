//-----------------------------------------------------------------------
// <copyright file="TitleAttributeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
#define ODIN_INSPECTOR
#define ODIN_INSPECTOR_3
#define ODIN_INSPECTOR_3_1
#define ODIN_INSPECTOR_3_2
#define ODIN_INSPECTOR_3_3
namespace Sirenix.OdinInspector.Editor.Drawers
{
#pragma warning disable

    using ValueResolvers;
    using Sirenix.Utilities.Editor;
    using UnityEditor;
    using UnityEngine;

    /// <summary>
    /// Draws properties marked with <see cref="TitleAttribute"/>.
    /// </summary>
    /// <seealso cref="TitleAttribute"/>
    /// <seealso cref="TitleGroupAttribute"/>
    [DrawerPriority(1, 0, 0)]
    public sealed class TitleAttributeDrawer : OdinAttributeDrawer<TitleAttribute>
    {
        private ValueResolver<string> titleResolver;
        private ValueResolver<string> subtitleResolver;

        protected override void Initialize()
        {
            titleResolver = ValueResolver.GetForString(Property, Attribute.Title);
            subtitleResolver = ValueResolver.GetForString(Property, Attribute.Subtitle);
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            // Don't draw added emtpy space for the first property.
            if (Property != Property.Tree.GetRootProperty(0))
            {
                EditorGUILayout.Space();
            }

            bool valid = true;

            if (titleResolver.HasError)
            {
                SirenixEditorGUI.ErrorMessageBox(titleResolver.ErrorMessage);
                valid = false;
            }

            if (subtitleResolver.HasError)
            {
                SirenixEditorGUI.ErrorMessageBox(subtitleResolver.ErrorMessage);
                valid = false;
            }

            if (valid)
            {
                SirenixEditorGUI.Title(
                    titleResolver.GetValue(),
                    subtitleResolver.GetValue(),
                    (TextAlignment)Attribute.TitleAlignment,
                    Attribute.HorizontalLine,
                    Attribute.Bold);
            }

            CallNextDrawer(label);
        }
    }
}
#endif