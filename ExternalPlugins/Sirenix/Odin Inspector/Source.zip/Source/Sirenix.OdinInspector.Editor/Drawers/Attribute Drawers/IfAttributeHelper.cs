//-----------------------------------------------------------------------
// <copyright file="IfAttributeHelper.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
#define ODIN_INSPECTOR
#define ODIN_INSPECTOR_3
#define ODIN_INSPECTOR_3_1
#define ODIN_INSPECTOR_3_2
#define ODIN_INSPECTOR_3_3
namespace Sirenix.OdinInspector.Editor.Drawers
{
#pragma warning disable

    using ValueResolvers;

    public class IfAttributeHelper
    {
        private readonly ValueResolver<object> valueResolver;
        
        private bool result;

        public bool DefaultResult;

        public string ErrorMessage { get; private set; }

        public IfAttributeHelper(InspectorProperty property, string memberName, bool defaultResult = false)
        {
            valueResolver = ValueResolver.Get<object>(property, memberName);
            ErrorMessage = valueResolver.ErrorMessage;
            DefaultResult = defaultResult;
        }

        public bool GetValue(object value)
        {
            if (ErrorMessage == null)
            {
                result = false;
                object resolvedValue = valueResolver.GetValue();

                if (resolvedValue is UnityEngine.Object)
                {
                    // Unity objects can be 'fake null', and to detect that we have to test the value as a Unity object.
                    result = ((UnityEngine.Object)resolvedValue) != null;
                }
                else if (resolvedValue is bool)
                {
                    result = (bool)resolvedValue;
                }
                else if (resolvedValue is string)
                {
                    result = string.IsNullOrEmpty((string)resolvedValue) == false;
                }
                else if (value == null)
                {
                    if (resolvedValue != null)
                    {
                        result = true;
                    }
                }
                else if (Equals(resolvedValue, value))
                {
                    result = true;
                }

                return result;
            }

            return DefaultResult;
        }
    }
}
#endif