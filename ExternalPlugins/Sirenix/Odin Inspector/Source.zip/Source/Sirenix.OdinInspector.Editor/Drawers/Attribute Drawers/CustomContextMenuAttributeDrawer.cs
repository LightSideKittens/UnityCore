//-----------------------------------------------------------------------
// <copyright file="CustomContextMenuAttributeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
#define ODIN_INSPECTOR
#define ODIN_INSPECTOR_3
#define ODIN_INSPECTOR_3_1
#define ODIN_INSPECTOR_3_2
#define ODIN_INSPECTOR_3_3
namespace Sirenix.OdinInspector.Editor.Drawers
{
#pragma warning disable

    using UnityEditor;
    using UnityEngine;
    using System.Collections.Generic;
    using System.Linq;
    using ActionResolvers;

    /// <summary>
    /// Adds a generic menu option to properties marked with <see cref="CustomContextMenuAttribute"/>.
    /// </summary>
    /// <seealso cref="CustomContextMenuAttribute"/>
    /// <seealso cref="DisableContextMenuAttribute"/>
    /// <seealso cref="OnInspectorGUIAttribute"/>
    [DrawerPriority(DrawerPriorityLevel.WrapperPriority)]
    public sealed class CustomContextMenuAttributeDrawer : OdinAttributeDrawer<CustomContextMenuAttribute>, IDefinesGenericMenuItems
    {
        private class ContextMenuInfo
        {
            public string Name;
            public ActionResolver Action;
        }

        private ContextMenuInfo info;
        private PropertyContext<Dictionary<CustomContextMenuAttribute, ContextMenuInfo>> contextMenuInfos;
        private PropertyContext<bool> populated;

        /// <summary>
        /// Populates the generic menu for the property.
        /// </summary>
        public void PopulateGenericMenu(InspectorProperty property, GenericMenu genericMenu)
        {
            if (populated.Value)
            {
                // Another custom context menu drawer has already populated the menu with all custom menu items
                // this is done so we can have menu item ordering consistency.
                return;
            }
            else
            {
                populated.Value = true;
            }
            
            if (contextMenuInfos.Value != null && contextMenuInfos.Value.Count > 0)
            {
                if (genericMenu.GetItemCount() > 0)
                {
                    genericMenu.AddSeparator("");
                }

                foreach (var item in contextMenuInfos.Value.OrderBy(n => n.Key.MenuItem ?? ""))
                {
                    var info = item.Value;

                    if (info.Action == null)
                    {
                        genericMenu.AddDisabledItem(new GUIContent(item.Key.MenuItem + " (Invalid)"));
                    }
                    else
                    {
                        genericMenu.AddItem(new GUIContent(info.Name), false, () =>
                        {
                            Property.RecordForUndo(info.Name);
                            info.Action.DoActionForAllSelectionIndices();
                        });
                    }
                }
            }
        }

        protected override void Initialize()
        {
            var property = Property;
            var attribute = Attribute;

            contextMenuInfos = property.Context.GetGlobal("CustomContextMenu", (Dictionary<CustomContextMenuAttribute, ContextMenuInfo>)null);
            populated = property.Context.GetGlobal("CustomContextMenu_Populated", false);

            if (contextMenuInfos.Value == null)
            {
                contextMenuInfos.Value = new Dictionary<CustomContextMenuAttribute, ContextMenuInfo>();
            }
            
            if (!contextMenuInfos.Value.TryGetValue(attribute, out info))
            {
                info = new ContextMenuInfo();
                info.Name = attribute.MenuItem;
                info.Action = ActionResolver.Get(Property, attribute.Action);

                contextMenuInfos.Value[attribute] = info;
            }

        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            populated.Value = false;

            if (info.Action.HasError)
            {
                info.Action.DrawError();
            }

            CallNextDrawer(label);
        }
    }
}
#endif