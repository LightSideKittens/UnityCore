//-----------------------------------------------------------------------
// <copyright file="InlineEditorAttributeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
#define ODIN_INSPECTOR
#define ODIN_INSPECTOR_3
#define ODIN_INSPECTOR_3_1
#define ODIN_INSPECTOR_3_2
#define ODIN_INSPECTOR_3_3
namespace Sirenix.OdinInspector.Editor.Drawers
{
#pragma warning disable

    using System;
    using Utilities;
    using Internal;
    using Sirenix.Utilities.Editor;
    using Serialization;
    using UnityEditor;
    using UnityEngine;
    using System.Collections.Generic;
    using System.Linq;
    using Internal.UIToolkitIntegration;
    using UnityEditor.UIElements;
    using System.Reflection;

    /// <summary>
    /// Static GUI information reguarding the InlineEditor attribute.
    /// </summary>
    public static class InlineEditorAttributeDrawer
    {
        /// <summary>
        /// Gets a value indicating how many InlineEditors we are currently in.
        /// </summary>
        public static int CurrentInlineEditorDrawDepth { get; internal set; }
    }

    /// <summary>
    /// Draws properties marked with <see cref="InlineEditorAttribute"/>.
    /// </summary>
    /// <seealso cref="InlineEditorAttribute"/>
    /// <seealso cref="DrawWithUnityAttribute"/>
    [DrawerPriority(0, 0, 3000)]
    public class InlineEditorAttributeDrawer<T> : OdinAttributeDrawer<InlineEditorAttribute, T>, IDisposable where T : UnityEngine.Object
    {
        public static readonly bool IsGameObject = typeof(T) == typeof(GameObject);

        private static Type animationClipEditorType = TwoWaySerializationBinder.Default.BindToType("UnityEditor.AnimationClipEditor");

        private static PropertyInfo materialForceVisibleProperty = typeof(MaterialEditor).GetProperty("forceVisible", Flags.AllMembers);
        private static Stack<LayoutSettings> layoutSettingsStack = new Stack<LayoutSettings>();
        private Editor editor;
        private Editor previewEditor;
        private UnityEngine.Object target;
        private Rect inlineEditorRect;
        private Vector2 scrollPos;
        private bool drawHeader;
        private bool drawGUI;
        private bool drawPreview;
        private bool alwaysVisible;
        private bool targetIsOpenForEdit;
        private OdinImGuiElement element;
        private bool hasCheckedCurrentEditorForElement;
        private bool allowSceneObjects;
        private bool isAnimationClip;

        /// <summary>
        /// Initializes this instance.
        /// </summary>
        protected override void Initialize()
        {
            if (Attribute.ExpandedHasValue && InlineEditorAttributeDrawer.CurrentInlineEditorDrawDepth == 0)
            {
                Property.State.Expanded = Attribute.Expanded;
            }
            
            allowSceneObjects = InspectorPropertyInfoUtility.InspectorPropertySupportsAssigningSceneReferences(Property);

            isAnimationClip = Property.ValueEntry.TypeOfValue == typeof(AnimationClip);
        }

        /// <summary>
        /// Draws the property layout.
        /// </summary>
        /// <param name="label">The label.</param>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            Rect valueRect;
            switch (Attribute.ObjectFieldMode)
            {
                case InlineEditorObjectFieldModes.Boxed:
                    alwaysVisible = false;
                    SirenixEditorGUI.BeginToolbarBox();
                    SirenixEditorGUI.BeginToolbarBoxHeader();
                    if (ValueEntry.SmartValue)
                    {
                        Property.State.Expanded = SirenixEditorGUI.Foldout(Property.State.Expanded, label, out valueRect);
                        DrawPolymorphicObjectField(valueRect);
                    }
                    else
                    {
                        DrawPolymorphicObjectField(label);
                    }
                    SirenixEditorGUI.EndToolbarBoxHeader();
                    GUIHelper.PushHierarchyMode(false);
                    DrawEditor();
                    GUIHelper.PopHierarchyMode();
                    SirenixEditorGUI.EndToolbarBox();
                    break;
                case InlineEditorObjectFieldModes.Foldout:
                    alwaysVisible = false;
                    if (ValueEntry.SmartValue)
                    {
                        Property.State.Expanded = SirenixEditorGUI.Foldout(Property.State.Expanded, label, out valueRect);
                        DrawPolymorphicObjectField(valueRect);
                    }
                    else
                    {
                        DrawPolymorphicObjectField(label);
                    }
                    EditorGUI.indentLevel++;
                    DrawEditor();
                    EditorGUI.indentLevel--;
                    break;
                case InlineEditorObjectFieldModes.Hidden:
                    alwaysVisible = true;
                    if (!(UnityEngine.Object)ValueEntry.WeakSmartValue)
                    {
                        DrawPolymorphicObjectField(label);
                    }
                    DrawEditor();
                    break;
                case InlineEditorObjectFieldModes.CompletelyHidden:
                    alwaysVisible = true;
                    DrawEditor();
                    break;
            }
        }

        private void DrawPolymorphicObjectField(Rect position)
        {
            bool isPolymorphic = ValueEntry.BaseValueType == typeof(object) ||
                                 !typeof(UnityEngine.Object).IsAssignableFrom(ValueEntry.BaseValueType) ||
                                 ValueEntry.BaseValueType.IsInterface;

            if (isPolymorphic)
            {
                if (GeneralDrawerConfig.Instance.useOldPolymorphicField)
                {
                    EditorGUI.BeginChangeCheck();
                    object newValue = OdinInternalEditorFields.PolymorphicObjectField(position, GUIContent.none, Property, allowSceneObjects);
                    if (EditorGUI.EndChangeCheck())
                    {
                        ValueEntry.Property.Tree.DelayActionUntilRepaint(() =>
                        {
                            ValueEntry.WeakValues[0] = newValue;
                            for (int j = 1; j < ValueEntry.ValueCount; j++)
                            {
                                // NOTE: "Sirenix.Serialization." is important for later Unity versions
                                ValueEntry.WeakValues[j] = Serialization.SerializationUtility.CreateCopy(newValue);
                            }
                        });
                    }
                }
                else
                {
                    OdinInternalEditorFields.PolymorphicObjectField(Property, OdinObjectSelectorIds.ODIN_DRAWER_FIELD,
                                                                    position, GUIContent.none, Property, allowSceneObjects);
                }
            }
            else
            {
                if (GeneralDrawerConfig.Instance.useOldUnityObjectField)
                {
                    ValueEntry.WeakSmartValue = OdinInternalEditorFields.UnityObjectField(position, null,
                                                                                               ValueEntry.WeakSmartValue as UnityEngine.Object,
                                                                                               ValueEntry.BaseValueType,
                                                                                               allowSceneObjects);
                }
                else
                {
                    OdinInternalEditorFields.UnityObjectField(Property, OdinObjectSelectorIds.ODIN_DRAWER_FIELD,
                                                              position, null, ValueEntry.WeakSmartValue as UnityEngine.Object,
                                                              ValueEntry.BaseValueType,
                                                              allowSceneObjects,
                                                              property: Property);
                }
            }
        }

        private void DrawPolymorphicObjectField(GUIContent label)
        {
            bool isPolymorphic = ValueEntry.BaseValueType == typeof(object) ||
                                 !typeof(UnityEngine.Object).IsAssignableFrom(ValueEntry.BaseValueType) ||
                                 ValueEntry.BaseValueType.IsInterface;

            if (isPolymorphic)
            {
                if (GeneralDrawerConfig.Instance.useOldPolymorphicField)
                {
                    EditorGUI.BeginChangeCheck();
                    object newValue = OdinInternalEditorFields.PolymorphicObjectField(label, Property, allowSceneObjects);
                    if (EditorGUI.EndChangeCheck())
                    {
                        ValueEntry.Property.Tree.DelayActionUntilRepaint(() =>
                        {
                            ValueEntry.WeakValues[0] = newValue;
                            for (int j = 1; j < ValueEntry.ValueCount; j++)
                            {
                                // NOTE: "Sirenix.Serialization." is important for later Unity versions
                                ValueEntry.WeakValues[j] = Serialization.SerializationUtility.CreateCopy(newValue);
                            }
                        });
                    }
                }
                else
                {
                    OdinInternalEditorFields.PolymorphicObjectField(Property, OdinObjectSelectorIds.ODIN_DRAWER_FIELD, label, Property, allowSceneObjects);
                }
            }
            else
            {
                if (GeneralDrawerConfig.Instance.useOldUnityObjectField)
                {
                    ValueEntry.WeakSmartValue = OdinInternalEditorFields.UnityObjectField(label, ValueEntry.WeakSmartValue as UnityEngine.Object,
                                                                                               ValueEntry.BaseValueType,
                                                                                               allowSceneObjects);
                }
                else
                {
                    OdinInternalEditorFields.UnityObjectField(Property, OdinObjectSelectorIds.ODIN_DRAWER_FIELD,
                                                              EditorGUILayout.GetControlRect(),
                                                              label, ValueEntry.WeakSmartValue as UnityEngine.Object,
                                                              ValueEntry.BaseValueType,
                                                              allowSceneObjects,
                                                              property: Property);
                }
            }
        }

        private OdinImGuiElement TryCreateInspectorElementAndSetClasses(Editor targetEditor)
        {
            if (targetEditor.GetType().GetMethod("CreateInspectorGUI", BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public) != null)
            {
                var element = new InspectorElement(targetEditor);
                return new OdinImGuiElement(element);
            }
            else
            {
                return null;
            }
        }

        private void DrawEditor()
        {
            var obj = ValueEntry.SmartValue;

            if (ValueEntry.ValueState == PropertyValueState.ReferencePathConflict)
            {
                SirenixEditorGUI.InfoMessageBox("reference-path-conflict");
            }
            else
            {
                if (alwaysVisible || SirenixEditorGUI.BeginFadeGroup(this, Property.State.Expanded))
                {
                    UpdateEditors();

                    if (Attribute.MaxHeight != 0)
                    {
                        scrollPos = EditorGUILayout.BeginScrollView(scrollPos, GUILayoutOptions.MaxHeight(200));
                    }

                    var prev = EditorGUI.showMixedValue;
                    EditorGUI.showMixedValue = false;
                    EditorGUI.BeginChangeCheck();
                    DoTheDrawing();
                    if (EditorGUI.EndChangeCheck())
                    {
                        var e = Property.BaseValueEntry as PropertyValueEntry;
                        if (e != null)
                        {
                            for (int i = 0; i < e.ValueCount; i++)
                            {
                                e.TriggerOnChildValueChanged(i);
                            }
                        }
                    }
                    EditorGUI.showMixedValue = prev;
                    if (Attribute.MaxHeight != 0)
                    {
                        EditorGUILayout.EndScrollView();
                    }
                }
                else
                {
                    if (editor != null)
                    {
                        DestroyEditors();
                    }
                }

                if (!alwaysVisible)
                {
                    SirenixEditorGUI.EndFadeGroup();
                }
            }

        }

        private void DoTheDrawing()
        {
            if (IsGameObject && !Attribute.DrawPreview)
            {
                SirenixEditorGUI.MessageBox("Odin does not currently have a full GameObject inspector window substitute implemented, so a GameObject's components cannot be directly inspected inline in the editor. Choose an InlineEditorMode that includes a preview to draw a GameObject preview.");
                OdinInternalEditorFields.UnityObjectField(ValueEntry.SmartValue, typeof(GameObject), allowSceneObjects);

                GUILayout.BeginHorizontal();
                {
                    GUIHelper.PushGUIEnabled(ValueEntry.SmartValue != null);

                    string text = ValueEntry.SmartValue != null ? ("Open Inspector window for " + ValueEntry.SmartValue.name) : "Open Inspector window (null)";

                    if (GUILayout.Button(GUIHelper.TempContent(text)))
                    {
                        GUIHelper.OpenInspectorWindow(ValueEntry.SmartValue);
                        GUIHelper.ExitGUI(true);
                    }

                    text = ValueEntry.SmartValue != null ? ("Select " + ValueEntry.SmartValue.name) : "Select GO (null)";

                    if (GUILayout.Button(GUIHelper.TempContent(text)))
                    {
                        Selection.activeObject = ValueEntry.SmartValue;
                        GUIHelper.ExitGUI(true);
                    }

                    GUIHelper.PopGUIEnabled();
                }
                GUILayout.EndHorizontal();
                return;
            }

            if (editor != null && editor.SafeIsUnityNull() == false)
            {
                SaveLayoutSettings();
                InlineEditorAttributeDrawer.CurrentInlineEditorDrawDepth++;
                try
                {
                    if (!targetIsOpenForEdit)
                    {
                        GUIHelper.PushGUIEnabled(false);
                    }


                    var alignment = Attribute.PreviewAlignment;
                    var drawPreviewHorizontally = drawPreview && (alignment == PreviewAlignment.Left || alignment == PreviewAlignment.Right);
                    var drawPreviewVertically = drawPreview && (alignment == PreviewAlignment.Top || alignment == PreviewAlignment.Bottom);

                    if (!drawGUI && drawPreviewHorizontally)
                    {
                        // There is nothing to draw left or right of.
                        drawPreviewHorizontally = false;
                        drawPreviewVertically = true;
                        alignment = alignment == PreviewAlignment.Left ? PreviewAlignment.Top : PreviewAlignment.Bottom;
                    }

                    if (drawPreviewHorizontally)
                    {
                        GUILayout.BeginHorizontal();

                        if (Attribute.PreviewAlignment == PreviewAlignment.Left)
                        {
                            GUILayout.BeginVertical();
                            DrawPreview(alignment);
                            GUILayout.EndVertical();
                        }

                        GUILayout.BeginVertical();
                    }
                    else if (drawPreviewVertically && Attribute.PreviewAlignment == PreviewAlignment.Top)
                    {
                        DrawPreview(alignment);
                    }

                    // Brace for impact
                    if (drawHeader)
                    {
                        var tmp = Event.current.rawType;
                        EditorGUILayout.BeginFadeGroup(0.9999f); // This one fixes some layout issues for reasons beyond me, but locks the input.
                        Event.current.type = tmp;                // Lets undo that shall we?
                        GUILayout.Space(0);                      // Yeah i know. But it removes some unwanted top padding.
                        editor.DrawHeader();
                        GUILayout.Space(1);                      // This adds the the 1 pixel border clipped from the fade group.
                        EditorGUILayout.EndFadeGroup();
                    }
                    else
                    {
                        // Many of unity editors will not work if the header is not drawn.
                        // So lets draw it anyway. -_-
                        GUIHelper.BeginDrawToNothing();
                        editor.DrawHeader();
                        GUIHelper.EndDrawToNothing();
                    }

                    if (drawGUI)
                    {
                        if (GeneralDrawerConfig.Instance.EnableUIToolkitSupport && !hasCheckedCurrentEditorForElement)
                        {
                            hasCheckedCurrentEditorForElement = true;
                            element = TryCreateInspectorElementAndSetClasses(editor);
                        }

                        if (GeneralDrawerConfig.Instance.EnableUIToolkitSupport && element != null)
                        {
                            ImguiElementUtils.EmbedVisualElementAndDrawItHere(element);
                        }
                        else
                        {
                            var prev = GeneralDrawerConfig.Instance.ShowMonoScriptInEditor;
                            try
                            {
                                GeneralDrawerConfig.Instance.ShowMonoScriptInEditor = false;
                                EditorGUILayout.BeginVertical();

                                var prevIsSet = UnityEditorInternal.InternalEditorUtility.GetIsInspectorExpanded(editor.target);

                                if (!drawHeader)
                                {
                                    UnityEditorInternal.InternalEditorUtility.SetIsInspectorExpanded(editor.target, true);
                                }

                                editor.OnInspectorGUI();

                                if (!drawHeader)
                                {
                                    UnityEditorInternal.InternalEditorUtility.SetIsInspectorExpanded(editor.target, prevIsSet);
                                }

                                EditorGUILayout.EndVertical();
                            }
                            finally
                            {
                                GeneralDrawerConfig.Instance.ShowMonoScriptInEditor = prev;
                            }
                        }
                    }

                    if (drawPreviewHorizontally)
                    {
                        GUILayout.EndVertical();

                        if (Attribute.PreviewAlignment == PreviewAlignment.Right)
                        {
                            GUILayout.BeginVertical();
                            DrawPreview(alignment);
                            GUILayout.EndVertical();
                        }

                        GUILayout.EndHorizontal();
                    }
                    else if (drawPreviewVertically && alignment == PreviewAlignment.Bottom)
                    {
                        DrawPreview(alignment);
                    }

                    if (!targetIsOpenForEdit)
                    {
                        GUIHelper.PopGUIEnabled();
                    }
                }
                catch (Exception ex)
                {
                    if (ex.IsExitGUIException())
                    {
                        throw ex.AsExitGUIException();
                    }
                    else
                    {
                        Debug.LogException(ex);
                    }
                }
                finally
                {
                    InlineEditorAttributeDrawer.CurrentInlineEditorDrawDepth--;
                    RestoreLayout();
                }
            }
        }

        private void DrawPreview(PreviewAlignment alignment)
        {
            var isHorizontal = alignment == PreviewAlignment.Left || alignment == PreviewAlignment.Right;

            // previewEditor.HasPreviewGUI() reports 'false' for GameObject from the scene. But the user has asked for a preview, so a preview they'll get!
            if (!drawPreview || (!previewEditor.HasPreviewGUI() && !(previewEditor.target is GameObject))) return;

            var size = isHorizontal ? Attribute.PreviewWidth : Attribute.PreviewHeight;

            if (isAnimationClip)
            {
                if (isHorizontal)
                {
                    if (size < 200)
                    {
                        size = 200;
                    }
                }
                else if (size < 90)
                {
                    size = 90;
                }
            }
            
            var layoutOptions = GUILayoutOptions.EmptyGUIOptions;

            switch (alignment)
            {
                case PreviewAlignment.Left:
                case PreviewAlignment.Right:
                layoutOptions = GUILayoutOptions.Width(size).ExpandHeight();
                break;
                case PreviewAlignment.Top:
                case PreviewAlignment.Bottom:
                layoutOptions = GUILayoutOptions.ExpandWidth().Height(size);
                break;
            }

            var rect = EditorGUILayout.GetControlRect(false, size, layoutOptions);
            
            var tmp = GUI.enabled;
            GUI.enabled = true;

            if (isAnimationClip && previewEditor.GetType() == animationClipEditorType)
            {
                // IMPORTANT: This method WILL set GUI.enabled = false in some cases, ensure to reverse that after exiting this scope.
                DrawAnimationClipEditorPreview(rect);
            }
            else
            {
                previewEditor.DrawPreview(rect);
            }

            GUI.enabled = tmp;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="rect"></param>
        /// <remarks>Will set <see cref="GUI.enabled">GUI.enabled</see> to false during some cases, to avoid the Preview eating events when it really shouldn't.</remarks>
        private void DrawAnimationClipEditorPreview(Rect rect)
        {
            // IMPORTANT: When AnimationClips are drawn inline without calling AnimationClipEditor.OnInspectorGUI, the timings are off.
            //            This workaround ensures OnInspectorGUI is called while drawing them in a disabled area with a size of 0,
            //            making the result of the drawing call invisible and non-interactive.
            if (!drawGUI)
            {
                GUIHelper.BeginDrawToNothing();
                {
                    previewEditor.OnInspectorGUI();
                }
                GUIHelper.EndDrawToNothing();
            }

            switch (Event.current.type)
            {
                case EventType.ScrollWheel:
                case EventType.DragPerform:
                    if (!Event.current.IsMouseOver(rect))
                    {
                        GUI.enabled = false;
                    }

                    break;
            }

            previewEditor.DrawPreview(rect);
        }

        private void UpdateEditors()
        {
            targetIsOpenForEdit = true;

            var unityObj = (UnityEngine.Object)ValueEntry.WeakSmartValue;

            if (editor != null && !unityObj)
            {
                DestroyEditors();
            }

            bool createNewEditor = unityObj != null && (editor == null || target != unityObj || target == null);

            if (createNewEditor && ValueEntry.ValueState == PropertyValueState.ReferenceValueConflict)
            {
                if (ValueEntry.WeakValues[0] == null)
                {
                    createNewEditor = false;
                }

                if (createNewEditor)
                {
                    var type = ValueEntry.WeakValues[0].GetType();

                    for (int i = 1; i < ValueEntry.ValueCount; i++)
                    {
                        if (!ValueEntry.Values[i] || ValueEntry.Values[i].GetType() != type)
                        {
                            createNewEditor = false;
                            break;
                        }
                    }
                }

                if (!createNewEditor)
                {
                    SirenixEditorGUI.InfoMessageBox("Cannot perform multi-editing on objects of different type.");
                }
            }

            if (createNewEditor)
            {
                target = unityObj;
                bool isGameObject = unityObj as GameObject;
                drawHeader = isGameObject ? Attribute.DrawHeader : Attribute.DrawHeader;
                drawGUI = isGameObject ? false : Attribute.DrawGUI;
                drawPreview = Attribute.DrawPreview || isGameObject && Attribute.DrawGUI;

                if (editor != null)
                {
                    DestroyEditors();
                }

                hasCheckedCurrentEditorForElement = false;
                editor = Editor.CreateEditor(ValueEntry.WeakValues.FilterCast<UnityEngine.Object>().ToArray());

                var component = target as Component;
                if (component != null)
                {
                    previewEditor = Editor.CreateEditor(component.gameObject);
                }
                else
                {
                    previewEditor = editor;
                }

                var materialEditor = editor as MaterialEditor;
                if (materialEditor != null && materialForceVisibleProperty != null)
                {
                    materialForceVisibleProperty.SetValue(materialEditor, true, null);
                }

                if (Attribute.DisableGUIForVCSLockedAssets && AssetDatabase.Contains(target))
                {
                    targetIsOpenForEdit = AssetDatabase.IsOpenForEdit(target);
                }
            }
        }

        private void DestroyEditors()
        {
            targetIsOpenForEdit = true;

            if (previewEditor != editor && previewEditor != null)
            {
                try
                {
                    UnityEngine.Object.DestroyImmediate(previewEditor);
                }
                catch { }
                previewEditor = null;
            }

            if (editor != null)
            {
                if (element != null)
                {
                    var capture = element;
                    element = null;

                    EditorApplication.delayCall += () =>
                    {
                        if (capture.parent != null)
                        {
                            capture?.RemoveFromHierarchy();
                        }
                    };
                }

                try
                {
                    UnityEngine.Object.DestroyImmediate(editor);
                }
                catch (Exception) { }
                editor = null;
            }
        }

        private static void SaveLayoutSettings()
        {
            layoutSettingsStack.Push(new LayoutSettings()
            {
                Skin = GUI.skin,
                Color = GUI.color,
                ContentColor = GUI.contentColor,
                BackgroundColor = GUI.backgroundColor,
                Enabled = GUI.enabled,
                IndentLevel = EditorGUI.indentLevel,
                FieldWidth = EditorGUIUtility.fieldWidth,
                LabelWidth = GUIHelper.ActualLabelWidth,
                HierarchyMode = EditorGUIUtility.hierarchyMode,
                WideMode = EditorGUIUtility.wideMode,
            });
        }

        private static void RestoreLayout()
        {
            var settings = layoutSettingsStack.Pop();

            GUI.skin = settings.Skin;
            GUI.color = settings.Color;
            GUI.contentColor = settings.ContentColor;
            GUI.backgroundColor = settings.BackgroundColor;
            GUI.enabled = settings.Enabled;
            EditorGUI.indentLevel = settings.IndentLevel;
            EditorGUIUtility.fieldWidth = settings.FieldWidth;
            GUIHelper.BetterLabelWidth = settings.LabelWidth;
            EditorGUIUtility.hierarchyMode = settings.HierarchyMode;
            EditorGUIUtility.wideMode = settings.WideMode;
        }

        void IDisposable.Dispose()
        {
            DestroyEditors();
        }

        private struct LayoutSettings
        {
            public GUISkin Skin;
            public Color Color;
            public Color ContentColor;
            public Color BackgroundColor;
            public bool Enabled;
            public int IndentLevel;
            public float FieldWidth;
            public float LabelWidth;
            public bool HierarchyMode;
            public bool WideMode;
        }
    }
}
#endif