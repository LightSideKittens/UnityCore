//-----------------------------------------------------------------------
// <copyright file="InfoBoxAttributeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
#define ODIN_INSPECTOR
#define ODIN_INSPECTOR_3
#define ODIN_INSPECTOR_3_1
#define ODIN_INSPECTOR_3_2
#define ODIN_INSPECTOR_3_3
namespace Sirenix.OdinInspector.Editor.Drawers
{
#pragma warning disable

    using Utilities.Editor;
    using UnityEngine;
    using UnityEditor;
    using ValueResolvers;

    /// <summary>
    /// Draws properties marked with <see cref="InfoBoxAttribute"/>.
    /// Draws an info box above the property. Error and warning info boxes can be tracked by Odin Scene Validator.
    /// </summary>
    /// <seealso cref="InfoBoxAttribute"/>
    /// <seealso cref="DetailedInfoBoxAttribute"/>
    /// <seealso cref="RequiredAttribute"/>
    /// <seealso cref="ValidateInputAttribute"/>
    [DrawerPriority(0, 10001, 0)]
    public sealed class InfoBoxAttributeDrawer : OdinAttributeDrawer<InfoBoxAttribute>
    {
        private bool drawMessageBox;
        private ValueResolver<bool> visibleIfResolver;
        private ValueResolver<string> messageResolver;
        private ValueResolver<Color> iconColorResolver;
        private MessageType messageType;

        protected override void Initialize()
        {
            visibleIfResolver = ValueResolver.Get(Property, Attribute.VisibleIf, true);
            messageResolver = ValueResolver.GetForString(Property, Attribute.Message);
            iconColorResolver = ValueResolver.Get(Property, Attribute.IconColor, EditorStyles.label.normal.textColor);

            drawMessageBox = visibleIfResolver.GetValue();

            switch (Attribute.InfoMessageType)
            {
                default:
                case InfoMessageType.None:
                    messageType = MessageType.None;
                    break;
                case InfoMessageType.Info:
                    messageType = MessageType.Info;
                    break;
                case InfoMessageType.Warning:
                    messageType = MessageType.Warning;
                    break;
                case InfoMessageType.Error:
                    messageType = MessageType.Error;
                    break;
            }
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            bool valid = true;

            if (visibleIfResolver.HasError)
            {
                SirenixEditorGUI.ErrorMessageBox(visibleIfResolver.ErrorMessage);
                valid = false;
            }

            if (messageResolver.HasError)
            {
                SirenixEditorGUI.ErrorMessageBox(messageResolver.ErrorMessage);
                valid = false;
            }

            if (iconColorResolver.HasError)
            {
                SirenixEditorGUI.ErrorMessageBox(iconColorResolver.ErrorMessage);
                valid = false;
            }

            if (!valid)
            {
                CallNextDrawer(label);
                return;
            }

            if (Attribute.GUIAlwaysEnabled)
            {
                GUIHelper.PushGUIEnabled(true);
            }

            if (Event.current.type == EventType.Layout)
            {
                drawMessageBox = visibleIfResolver.GetValue();
            }

            if (drawMessageBox)
            {
                var message = messageResolver.GetValue();

                if (Attribute.HasDefinedIcon)
                {
                    SirenixEditorGUI.IconMessageBox(message, Attribute.Icon, iconColorResolver.GetValue());
                }
                else
                {
                    SirenixEditorGUI.MessageBox(message, messageType);
                }
            }

            if (Attribute.GUIAlwaysEnabled)
            {
                GUIHelper.PopGUIEnabled();
            }

            CallNextDrawer(label);
        }
    }
}
#endif